package com.posun.view.dragui;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by zyq on 2017/2/10.
 */
public class DrageMeun extends LinearLayout implements View.OnClickListener{
    protected boolean isopen=false;
    protected int openwidth=98;
    public DrageMeun(Context context) {
        super(context);
        initview();
    }
    private void initview() {
        setOrientation(HORIZONTAL);
        LayoutParams layoutParamsp=new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.MATCH_PARENT);
        setLayoutParams(layoutParamsp);
        TextView textView=new TextView(getContext());
        textView.setText("bottom ");
        textView.setBackgroundColor(Color.YELLOW);
        textView.setTextColor(Color.BLACK);
        TextView textView1=new TextView(getContext());
        textView1.setText("hahabottom ");
        textView1.setBackgroundColor(Color.GREEN);
        textView1.setTextColor(Color.BLACK);
        this.addView(textView1,layoutParamsp);
        this.addView(textView,layoutParamsp);
    }

    @Override
    public void addView(View child, ViewGroup.LayoutParams params) {
        super.addView(child, params);
        child.setOnClickListener(this);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        openwidth=getMeasuredWidth();
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(getContext(), "565656565", Toast.LENGTH_SHORT).show();
    }
}
