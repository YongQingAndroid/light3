package com.posun.view;

import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.view.KeyEvent;
import android.view.Window;

/**
 * Created by qing on 2017/3/3.
 */

public class QV7Dialog extends android.support.v7.app.AlertDialog{
    private Window window;
    protected QV7Dialog(@NonNull Context context, @StyleRes int themeResId) {
        super(context, themeResId);
    }
    public QV7Dialog(@NonNull Context context) {
        super(context);
    }
    private void init() {
        this.setCancelable(false);
        window = getWindow();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        initEvent();
    }

    @Override
    public void show() {
        super.show();
    }



    private void initEvent() {
        this.setOnKeyListener(new OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                if (keyEvent.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    QV7Dialog.this.cancel();
                }
                return false;
            }
        });
    }
}
