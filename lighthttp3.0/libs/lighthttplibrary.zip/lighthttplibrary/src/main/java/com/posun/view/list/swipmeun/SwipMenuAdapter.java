package com.posun.view.list.swipmeun;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.ColorInt;
import android.support.annotation.LayoutRes;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.posun.unit.QlightUnit;
import com.posun.view.list.listener.RecyclerTouchListener;

import java.util.ArrayList;
import java.util.List;

/**
 * package kotlinTest:com.posun.view.list.swipmeun.SwipMenuAdapter.class
 * 作者：zyq on 2017/3/21 14:57
 * 邮箱：zyq@posun.com
 */
public class SwipMenuAdapter {
    private FrameLayout rootView;
    private List<Integer> meun_ids = new ArrayList<>();
    private List<meunEntity> entities = new ArrayList<>();
    private LinearLayout meun_group;
    private Context context;
    private ViewGroup.LayoutParams lpmeun;
    private RecyclerTouchListener onTouchListener;
    private int rootid, groupid, minwight;
    private RecyclerTouchListener.OnSwipeOptionsClickListener listener;
    private boolean issingle = true;

    public SwipMenuAdapter(Activity context, RecyclerView recyclerview) {
        this.context = context;
        onTouchListener = new RecyclerTouchListener(context, recyclerview);
        rootid = QlightUnit.sNextGeneratedId.getAndIncrement();
        groupid = QlightUnit.sNextGeneratedId.getAndIncrement();
        minwight = QlightUnit.dip2px(context, 80);
    }

    public void setOnSwipeOptionsClickListener(RecyclerTouchListener.OnSwipeOptionsClickListener listener) {
        this.listener = listener;
    }

    public RecyclerTouchListener getOnTouchListener() {
        return onTouchListener;
    }

    private void init() {
        rootView = new FrameLayout(context);
        rootView.setId(rootid);
        rootView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        meun_group = new LinearLayout(context);
        meun_group.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.RIGHT;
        meun_group.setId(groupid);
        meun_group.setLayoutParams(lp);
        lpmeun = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    public SwipMenuAdapter addMeun(String text, @ColorInt int textcolor, @ColorInt int BgColor) {
        meunEntity entity = new meunEntity();
        entity.setTextColor(textcolor);
        entity.setText(text);
        entity.setBgColor(BgColor);
        int id = QlightUnit.sNextGeneratedId.getAndIncrement();
        entity.setId(id);
        entities.add(entity);
        meun_ids.add(id);
        return this;
    }

    public SwipMenuAdapter addMeun(@LayoutRes int meun) {
        return this;
    }

    private void setMeunView() {
        for (meunEntity meun : entities) {
            TextView item = new TextView(context);
            item.setGravity(Gravity.CENTER);
            item.setBackgroundColor(meun.getBgColor());
            item.setTextColor(meun.getTextColor());
            item.setText(meun.getText());
//            item.setMinWidth(minwight);
            item.setId(meun.getId());
            item.setPadding(20, 20, 20, 20);
            meun_group.addView(item, lpmeun);
        }
    }

    public void setContentView(View view) {
        init();
        setMeunView();
        rootView.addView(meun_group);
        rootView.addView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (issingle) {
            if (listener == null) {
                listener = new RecyclerTouchListener.OnSwipeOptionsClickListener() {
                    @Override
                    public void onSwipeOptionClicked(View meun, int position) {

                    }
                };
            }
            onTouchListener.setSwipeable(true)
                    .setSwipeOptionViews((Integer[]) meun_ids.toArray(new Integer[meun_ids.size()]))
                    .setSwipeable(view.getId(), meun_group.getId(), listener);
            issingle = !issingle;
        }
    }

    class meunEntity {
        private String text;
        private int textColor;
        private int BgColor;
        private int id;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public int getBgColor() {
            return BgColor;
        }

        public void setBgColor(int bgColor) {
            BgColor = bgColor;
        }

        public int getTextColor() {
            return textColor;
        }

        public void setTextColor(int textColor) {
            this.textColor = textColor;
        }
    }

    public View getView() {

        return rootView;
    }
}
