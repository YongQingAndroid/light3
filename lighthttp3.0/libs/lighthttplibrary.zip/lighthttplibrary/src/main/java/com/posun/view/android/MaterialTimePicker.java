package com.posun.view.android;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * package kotlinTest:com.posun.view.android.MaterialTimePicker.class
 * 作者：zyq on 2017/7/18 09:33
 * 邮箱：zyq@posun.com
 */
public class MaterialTimePicker extends DialogFragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
