package com.posun.lighthttplibrary.lightHttp;
import java.util.HashMap;
import java.util.Map;
/**
 * Created by dell on 2017/2/14.
 */
public class QLightHttpUrlParameterBuilder {
    private Map<String,String> args=new HashMap<>();
    public QLightHttpUrlParameterBuilder setValue(String key,String value){
        args.put(key, value);
        return this;
    }
    public void clear(){
        args.clear();
    }
    public Map<String,String> getValue(){
        return args;
    }
}
