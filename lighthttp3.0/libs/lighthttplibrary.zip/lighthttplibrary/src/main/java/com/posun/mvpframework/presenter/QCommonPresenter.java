package com.posun.mvpframework.presenter;
import com.posun.mvpframework.view.BaseViewInterface;

import java.lang.reflect.InvocationHandler;

/**
 * package kotlinTest:com.posun.mvpframework.presenter.QCommonPresenter.class
 * 作者：zyq on 2017/3/20 11:25
 * 邮箱：zyq@posun.com
 */
public class QCommonPresenter {
   public <T>T getInstent(Object object,Class<T> clazz, BaseViewInterface baseviewinterface){
       InvocationHandler handler = new PraseModleHandler(object,baseviewinterface);
       Object ob = java.lang.reflect.Proxy.newProxyInstance(object.getClass().getClassLoader(), new Class<?>[]{clazz}, handler);
       return (T)ob;
   }

}
