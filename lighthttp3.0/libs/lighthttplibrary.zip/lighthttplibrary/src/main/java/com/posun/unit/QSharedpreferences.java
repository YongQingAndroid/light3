package com.posun.unit;

import android.content.SharedPreferences;

import com.alibaba.fastjson.JSON;

import java.util.List;

/**
 * package new_space:com.posun.unit.QSharedpreferences.class
 * 作者：zyq on 2017/3/10 08:53
 * 邮箱：zyq@posun.com
 */
public class QSharedpreferences{
    private  SharedPreferences sp;
    public void init(SharedPreferences sp){
         this.sp=sp;
    }
    public <T>T getObject(String key,T item,Class<T> clazz){
        if(sp==null){
            return item;
        }
       String value= sp.getString(key,"");
        if(!QlightUnit.isEmpty(value)){
            return JSON.parseObject(value,clazz);
        }
        return item;
    }
    public <T>List<T> getArrayObject(String key, List<T> item, Class<T> clazz){
        if(sp==null){
            return item;
        }
        String value= sp.getString(key,"");
        if(!QlightUnit.isEmpty(value)){
            return JSON.parseArray(value,clazz);
        }
        return item;
    }
    public <T>T getObjuect(String key,T item,Class<T> clazz){
        if(sp==null){
            return item;
        }
        String value= sp.getString(key,"");
        if(!QlightUnit.isEmpty(value)){
            return JSON.parseObject(value,clazz);
        }
        return item;
    }
    public void putObject(String key,Object object){
        if(sp!=null){
           sp.edit().putString(key, JSON.toJSONString(object)).commit();
        }
    }
    public SharedPreferences.Editor getEdit(){
        if(sp!=null){
           return sp.edit();
        }
        return null;
    }
}
