package com.posun.lighthttplibrary;

/**
 * Created by zyq on 2016/12/1.
 * okhttp 自定义网络异常
 */
public class OkHttpException extends RuntimeException{
    String request;
    public OkHttpException(String msg,String request){
        super(msg);
        this.request=request;
    }
    public OkHttpException(String msg){
        super(msg);
    }
    public String getRequest(){
        return request;
    }
}
