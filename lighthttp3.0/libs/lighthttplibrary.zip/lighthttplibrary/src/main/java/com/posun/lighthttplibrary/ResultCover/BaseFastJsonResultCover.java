package com.posun.lighthttplibrary.ResultCover;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.posun.lighthttplibrary.QLightHttp;

import java.lang.reflect.Type;

import okhttp3.Response;

/**
 * This network framework is based on the production of okhttp
 * Network framework free open source, and the final right to interpret the author.
 * The author will go regularly to update the business code, but no obligation to notify the user.
 * My open source community account is fengling136
 * Welcome attention
 * Thanks for your use
 * the power by ZYQ
 */
public class BaseFastJsonResultCover implements QLightHttp.LightHttpCover {
    private boolean isdebug=false;
    @Override
    public Object just(Response mObject, Type type,Object expandValue)throws Exception{
        String json=mObject.body().string();
        if(isdebug){
            Log.e(QLightHttp.TAG,json);
        }
        return JSON.parseObject(json,type);
    }
    public static BaseFastJsonResultCover creat(){
       return creat(false);
    }
    public BaseFastJsonResultCover(boolean isdebug){
     this.isdebug=isdebug;
    }
    public static BaseFastJsonResultCover creat(boolean isdebug){
        return new BaseFastJsonResultCover(isdebug);
    }
}
