package com.posun.lighthttplibrary;

import com.posun.lighthttplibrary.ResultCover.BaseFastJsonResultCover;
import com.posun.lighthttplibrary.ResultCover.BaseSoapPullXmlResultCover;
import com.posun.lighthttplibrary.ResultCover.BaseStreamResultCover;
import com.posun.lighthttplibrary.adapterCover.QBaseRxAdapterCover;
import com.posun.lighthttplibrary.annotation.LightHeard;
import com.posun.lighthttplibrary.annotation.LightHttpGet;
import com.posun.lighthttplibrary.annotation.LightHttpPost;
import com.posun.lighthttplibrary.annotation.LightHttpSoapXmlElement;
import com.posun.lighthttplibrary.annotation.LightHttpMultiStream;
import com.posun.lighthttplibrary.annotation.LightHttpStream;
import com.posun.lighthttplibrary.annotation.LightPostEntity;
import com.posun.lighthttplibrary.annotation.LightQuery;
import com.posun.lighthttplibrary.annotation.LightQueryPath;
import com.posun.lighthttplibrary.annotation.LightSoapBody;
import com.posun.lighthttplibrary.annotation.LightUploadPath;
import com.posun.lighthttplibrary.lightHttp.QCall;
import com.posun.lighthttplibrary.lightHttp.QLightCall;
import com.posun.lighthttplibrary.lightHttp.QLightResponseEntity;

import java.util.List;

import okhttp3.Call;
import okhttp3.Request;
import rx.Observable;

/**
 * Created by dell on 2017/1/23.
 */
public class QlightHttpExample{

    /**
     * 请求服务接口实例
     */
    interface LightHttpserver {
        /**
         * 简单的get请求
         * @param key_value 替换url里面包含的关键字
         * @param value    url裏面键值对
         * @LightHttpGet 声明为get请求
         * @LightHeard 自定义请求头
         * @LightQueryPath url埋藏参数
         */
        @LightHttpGet("url/{name}/")
        @LightHeard(key = "key", value = "value")/***非必须参数自定义请求头(注意在java8标准中@LightHeard可以重复使用来设置多个请求头，非java8环境多个请求头时请使用构造器)**/
        Observable<TestBean> simpleGet(@LightQuery("page") String value, @LightQueryPath("{name}") String key_value);
        /**
         *Mult文件上传
         * */
        @LightHttpPost("url")
        @LightHttpMultiStream
        @LightHeard(key = "key", value = "value")/***非必须参数**/
        Observable<String> simpleMultUpload(@LightUploadPath String path, @LightUploadPath String path1);
        /**
         *文件上传
         * */
        @LightHttpPost("url")
        @LightHttpStream
        @LightHeard(key = "key", value = "value")/***非必须参数**/
        Observable<String> simpleUpload(@LightUploadPath String path, @LightUploadPath String path1);

        /**
         * post請求
         * */
        @LightHttpPost("url")
        @LightHeard(key = "key", value = "value")/***非必须参数**/
        Observable<String> simplePost(@LightPostEntity TestBean tableData, @LightQuery("key") String value);
        /**
         * 非Rxjava模式下的请求
         * */
        @LightHttpGet("url")
        @LightHeard(key = "key", value = "value")/***非必须参数**/
        QLightCall<List<TestBean>> simpleGetNomer1(@LightQuery("key") String value, @LightQueryPath("keyworld") String keyvalue);
        /**********************************************以下为soap请求实例**************************************************************************/
        /**
         *@param soap xml请求根服务器自定义
         */
        @LightHeard(key = "SOAPAction",value = "urn:simgpleSoap")/**当前约束SOAPAction 以及调用的对象函数**/
        @LightHttpPost("url")
        @LightHttpSoapXmlElement("ns:return")/**返回xml的数据根节点（根据实际情况自定义）*/
        Observable<TestBean> simgpleSoap(@LightSoapBody String soap);
    }
    /**
     * 调用工厂实例
     * */
    class rxFactory{
        {
            QLightHttp lightHttp=new QLightHttp.Builder() /**获取QlightHttp构造器**/
                    .addAdapterCover(QBaseRxAdapterCover.creat()) /**Rxjava 支持，不添加默認使用普通模式，即lightCall**/
                    .addResultCover(BaseFastJsonResultCover.creat()) /**重点！必须，网络回调解释器，可继承LightHttpCover自定义解释，包含FastJson，Gson，等，可以自定义服务器字段判断，约束**/
                    .addResultCover(BaseSoapPullXmlResultCover.create())/**重点！必须，网络回调解释器，xml模式，不可以与json共存*/
                    .addResultCover(BaseStreamResultCover.creat()) /**重点！必须，网络回调解释器，服务器返回文件流（适用文件下载）***/
                    .setBuilder(new Request.Builder()) /**（非必须）自定义okttpRequest**/
                    .src("baseUrl")/**（必须）请求的网络路径接口**/
                    .setHeader("key","value")/**（非必须）自定义请求头*/
                    .build();
         lightHttp.creat(LightHttpserver.class).simpleGetNomer1(null,null).call(new QCall<QLightResponseEntity<List<TestBean>>>() {
                @Override
                public void onSuccess(QLightResponseEntity<List<TestBean>> item) {

                }
                @Override
                public void onFaile(Exception e) {

                }
            });
        }
    }
    {
        /******************************************************************无需配置的简单调用*****************************************************************************************/
        try {
            /**********************************同步请求******************************************************/
            new QLightHttp.SimpleRequest().get("https://www.baidu.com?page=1&&count=3",TestBean.class);
            new QLightHttp.SimpleRequest().setHeard("key","value").get("https://www.baidu.com?page=1&&count=3",TestBean.class);
            new QLightHttp.SimpleRequest().post("https://www.baidu.com","565655555555");
            /**********异步获取网络对象*****************/
            new QLightHttp.SimpleRequest().get("https://www.baidu.com", TestBean.class, new QCall<QLightResponseEntity<TestBean>>() {
                @Override
                public void onSuccess(QLightResponseEntity<TestBean> item) {
                }
                @Override
                public void onFaile(Exception e) {

                }
            });
            /****************获取网络对象列表*****************************/
            new QLightHttp.SimpleRequest().getList("https://www.baidu.com", TestBean.class, new QCall<QLightResponseEntity<List<TestBean>>>() {
                @Override
                public void onSuccess(QLightResponseEntity<List<TestBean>> item) {

                }

                @Override
                public void onFaile(Exception e) {

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 測試實體對象
     * */
    class TestBean {

    }
}
