package com.resources;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.InputType;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.posun.lighthttplibrary.R;

/**
 * Created by dell on 2016/7/14.
 */
public class QEditorWithLable extends LinearLayout implements EdtextInterface {
    private int Orientation=LinearLayout.HORIZONTAL;
    private EditText mEditText;
    private TextView mTextView;
    private final String PWD="textPassword";
    private String labletext,lable_editor_type,lableeditor_hide;
    private int mColor=0;
    private float font_size=12;
    private Drawable rightDraw,leftDraw;
    public QEditorWithLable(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setGravity(Gravity.CENTER_VERTICAL);
         TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.lableView);
         labletext = a.getString(R.styleable.lableView_labletext);
         lable_editor_type = a.getString(R.styleable.lableView_lableeditor_inputtype);
         lableeditor_hide = a.getString(R.styleable.lableView_lableeditor_hide);
         mColor=a.getColor(R.styleable.lableView_labletextcolor, Color.BLACK);
         rightDraw= a.getDrawable(R.styleable.lableView_lable_right_drawable);
         leftDraw=a.getDrawable(R.styleable.lableView_lable_left_drawable);
         font_size=a.getDimensionPixelSize(R.styleable.lableView_lable_deitor_fontsize,12);
         a.recycle();
         InitUi();
    }
    public void setViewOnClickListner(final OnClickListener listner){
        mEditText.setFocusable(false);
        mEditText.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                listner.onClick(QEditorWithLable.this);
            }
        });
    }
    private void InitUi(){
        LayoutParams leftLp;
        LayoutParams rifhtLp;
        mEditText=new EditText(getContext());
        mEditText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        mEditText.setBackgroundResource(android.R.color.transparent);
        mTextView=new TextView(getContext());
        Orientation=this.getOrientation();
        switch (Orientation){
            case LinearLayout.HORIZONTAL:
                leftLp=new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.MATCH_PARENT);
                mTextView.setGravity(Gravity.CENTER_VERTICAL);
                mTextView.setLayoutParams(leftLp);
                rifhtLp=new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
                rifhtLp.setMargins(5,0,0,0);
                mEditText.setGravity(Gravity.CENTER_VERTICAL);
                mEditText.setLayoutParams(rifhtLp);
                this.addView(mTextView);
                this.addView(mEditText);
                break;
            case LinearLayout.VERTICAL:
                leftLp=new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT,1);
                mTextView.setLayoutParams(leftLp);
                rifhtLp=new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT,1);
                mEditText.setLayoutParams(rifhtLp);
                this.addView(mTextView);
                this.addView(mEditText);
                break;
        }
        mEditText.setTextSize(font_size);
        mTextView.setText(labletext);
        mTextView.setTextColor(mColor);
        if(PWD.equals(lable_editor_type)){
            mEditText.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        mTextView.setTextSize(font_size);
        if(rightDraw!=null){
            rightDraw.setBounds(0, 0, rightDraw.getMinimumWidth(), rightDraw.getMinimumHeight());
            mEditText.setCompoundDrawables(null,null,rightDraw,null);
        }
        if(leftDraw!=null){
            leftDraw.setBounds(0, 0, leftDraw.getMinimumWidth(), leftDraw.getMinimumHeight());
            mTextView.setCompoundDrawables(leftDraw,null,null,null);
        }
        if(!TextUtils.isEmpty(lableeditor_hide)){
            mEditText.setHint(lableeditor_hide);
        }
      //  this.setOrientation(LinearLayout.HORIZONTAL);
    }
    public void setLableText(String value){
         mTextView.setText(value);
    }
    public void setRightImg(int img){
        Drawable img_off = getContext().getResources().getDrawable(img);
        img_off.setBounds(0, 0, img_off.getMinimumWidth(), img_off.getMinimumHeight());
        mEditText.setCompoundDrawables(null,null,img_off,null);
    }
    public EditText getEditText(){
        return mEditText;
    }
    public void setFocusable(boolean flage){
        mEditText.setFocusable(flage);
    }
    public String getText(){
        return mEditText.getText().toString();
    }
    public void setText(String value){
        mEditText.setText(value);
    }

    @Override
    public String getViewText() {
        return getText();
    }

    @Override
    public void setViewText(String value) {
        setText(value);
    }
}
