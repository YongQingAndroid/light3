package com.posun.view.ios;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.posun.unit.QlightUnit;
import com.posun.view.QDialog;

/**
 * Created by qing on 2017/3/3.
 */

public class IOSUpDataDialog extends QDialog {
    private int mColor = Color.parseColor("#1E82FF");
    private IOSLineProgress lineProgress;
    public IOSUpDataDialog(Context context) {
        super(context);
        super.setGravity(QGriavty.CENTER);
        initIos();
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void initIos() {
        LinearLayout IOSGroup = new LinearLayout(getContext());
        LinearLayout content = new LinearLayout(getContext());
        int width = QlightUnit.dip2px(getContext(), 250);
        int height = QlightUnit.dip2px(getContext(), 130);
        LinearLayout.LayoutParams rootlp = new LinearLayout.LayoutParams(width, height);
        content.setLayoutParams(rootlp);
        content.setBackground(new IOSDrawable());
        content.setOrientation(LinearLayout.VERTICAL);
        IOSGroup.setGravity(Gravity.CENTER);
        IOSGroup.addView(content);
        LinearLayout.LayoutParams titellp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        TextView textView = new TextView(getContext());
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(mColor);
        textView.setText("检查到新版本");
        content.addView(textView, titellp);
        lineProgress = new IOSLineProgress(getContext());
        lineProgress.setlinecolor(mColor);
        lineProgress.setprogress(70);
        content.addView(lineProgress, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, QlightUnit.dip2px(getContext(),10)));
        /******************************************************/
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setGravity(Gravity.CENTER_VERTICAL);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        TextView sure = new TextView(getContext());
        sure.setTextColor(Color.RED);
        sure.setGravity(Gravity.CENTER);
        sure.setText("确定");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, QlightUnit.dip2px(getContext(), 45), 1);
        TextView cancel = new TextView(getContext());
        cancel.setTextColor(mColor);
        cancel.setGravity(Gravity.CENTER);
        cancel.setText("取消");
        linearLayout.addView(cancel, lp);
        View line = new View(getContext());
        line.setBackgroundColor(mColor);
        linearLayout.addView(line, new ViewGroup.LayoutParams(1, ViewGroup.LayoutParams.MATCH_PARENT));
        linearLayout.addView(sure, lp);
        content.addView(linearLayout, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        super.setContentView(IOSGroup);
    }

}
