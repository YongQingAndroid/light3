package com.posun.view.list.adapter;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.posun.view.dragui.HorizontalDragGoup;
import com.posun.view.list.swipmeun.SwipMenuAdapter;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用适配器描述
 * Created by zyq on 2017/1/10.
 */
public final class BaseRecyAdapter extends RecyclerView.Adapter<BaseRecyAdapter.Holder> {
    private int layout_id;
    private Class holder_Class = Holder.class;
    private List<?> data;
    private boolean haSwipeMenu=false;
    private TypeFace callback;
    private boolean isSingleType=true;
    private Map<Integer,Integer> Views;
    private Map<Integer,Class> Holders;
    private Map<String,Object> mGlobalValue;
    private View.OnClickListener listener;
    private SwipMenuAdapter swipmenuadapter;
    private QBaseRecyHolder.ItemClickListener itemClickListener;
    public BaseRecyAdapter(List<?> data, Class holder_Class, int layout_id) {
        this.data = data;
        this.holder_Class = holder_Class;
        bindLayout(layout_id);
    }
    /**
     * 是否绑定当前BaseRecyAdapter的生命周期
     * **/
    public void HasGlobalValue(boolean arg){
        if(arg){
            mGlobalValue=new HashMap<>();
        }
    }
    /**
     * 侧滑菜单适配器
     * **/
    public void setSwipMenuAdapter(SwipMenuAdapter swipmenuadapter){
        this.swipmenuadapter=swipmenuadapter;
        this.haSwipeMenu=true;
    }
    public BaseRecyAdapter(List<?> data) {
        this.data = data;
    }
    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(isSingleType){
            View rootView = LayoutInflater.from(parent.getContext()).inflate(layout_id, parent, false);
            Holder mHolder;
            if(haSwipeMenu){
                swipmenuadapter.setContentView(rootView);
                 mHolder= new Holder(swipmenuadapter.getView(),holder_Class);
            }else{
                 mHolder= new Holder(rootView,holder_Class);
            }
            return mHolder;
        }else{
            View rootView = LayoutInflater.from(parent.getContext()).inflate(Views.get(viewType), parent, false);
            Holder mHolder;
            if(haSwipeMenu){
                swipmenuadapter.setContentView(rootView);
                mHolder= new Holder(swipmenuadapter.getView(),Holders.get(viewType));
            }else{
                mHolder= new Holder(rootView,Holders.get(viewType));
            }
            return mHolder;
        }
    }

    public SwipMenuAdapter getSwipmenuAdapter() {
        return swipmenuadapter;
    }
    @Override
    public int getItemViewType(int position) {
        if(!isSingleType&&callback!=null){
          return  callback.getItemType(position);
        }
        return super.getItemViewType(position);
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        holder.baseRecyHolderImp.BindView(data.get(position),position);
    }

    public void bindLayout(int layout_id) {
        this.layout_id = layout_id;
    }

    @Override
    public int getItemCount() {
        if(data==null||data.size()<1){
            return 0;
        }
        return data.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        protected BaseRecyHolderImp baseRecyHolderImp;
        public Holder(View itemView,Class<?> classname) {
            super(itemView);
            try {
                Constructor constructor = classname.getDeclaredConstructor(View.class,List.class,Map.class);
                constructor.setAccessible(true);
                baseRecyHolderImp = (BaseRecyHolderImp) constructor.newInstance(new Object[]{itemView,data,mGlobalValue});
                baseRecyHolderImp.addOnitemClickListener(itemClickListener);
                baseRecyHolderImp.bindParentHolder(Holder.this);
                baseRecyHolderImp.bindEvent(itemView,listener);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @Deprecated
    public void bindOnItemClicklistener(QBaseRecyHolder.ItemClickListener itemClickListener){
        this.itemClickListener=itemClickListener;
    }
    @Deprecated
    public void bindEvent(View.OnClickListener listener){
        this.listener=listener;
    }
    public void  setViewType(TypeFace callback){
        this.callback=callback;
        isSingleType=false;
    }
    public void setViews(Map<Integer,Integer> mviews,Map<Integer,Class> holders){
        Holders=holders;
        Views=mviews;
    }
    public static interface TypeFace{
        int getItemType(int position);
    }

}
