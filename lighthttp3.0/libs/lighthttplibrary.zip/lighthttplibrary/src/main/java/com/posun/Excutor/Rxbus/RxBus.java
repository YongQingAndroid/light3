package com.posun.Excutor.Rxbus;
import android.support.annotation.NonNull;
import java.util.Enumeration;
import java.util.Hashtable;
import rx.Observable;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;
/**
 *  事件消息总线
 *  基于rxjava 实现类eventBus 事件队列分发，
 *  普通模式下可使用事件广播分发，busevent消息包装类可以传递flage 实现事件定位
 *  适用大部分情况
 *  linkmap模式下既可以广播分发事件，也可以更精确定位回调（定位时更小资源开销，重复使用会自动覆盖相同广播id事件），但是这个不是线程安全的（已解决线程安全）
 *  切在linkmap模式下post一个消息有且仅有一次，当对象被销毁时当前消息为失败，切注册时必须声明当前为linkedmap模式，同一个app里面两种模式可以混合使用
 *  注意：在activity中 由于finish方法并不能在rxbus销毁注册的
 *  因此,需要在销毁方法里面调用解除注册，否则会造成内存泄露
 *  消息不受线程和activity，fragment限制，不受activity在栈中状态限制（可以更新非栈顶activity数据），
 *  多线程无需使用intent封装传递，也无需序列化为二进制，但夸进程需要使用intent封装
 *  THE POWER BY ZYQ
 * */
public class RxBus {
    private static RxBus instance;
    private Hashtable<Object,Subject> subjectList=new Hashtable<>();
    private RxBus() {
    }
    public static synchronized RxBus  getInstance() {
        if (null == instance) {
            instance = new RxBus();
        }
        return instance;
    }
    public synchronized <T> Observable<T> register(@NonNull Object object) {
        Subject<T, T> subject = PublishSubject.create();
        subjectList.put(object,subject);
        return subject;
    }
    public synchronized <T> Observable<T> linkedRegister(@NonNull Integer object) {
        Subject<T, T> subject = PublishSubject.create();
        subjectList.put(object,subject);
        return subject;
    }
    public synchronized void unregister(Object object) {
        subjectList.remove(object);
    }
    @Deprecated
    public synchronized void unregisterAll() {
        subjectList.clear();
    }
    public void post(@NonNull Object content) {
        synchronized (this) {
            Enumeration e = subjectList.keys();
            while( e. hasMoreElements() ){
                subjectList.get(e.nextElement()).onNext(content);
            }
        }
    }
    public void linkedPost(@NonNull Object content,@NonNull Object key) {
        synchronized (this) {
                if(key instanceof Integer){
                    subjectList.get(key).onNext(content);
                }
        }
    }
}