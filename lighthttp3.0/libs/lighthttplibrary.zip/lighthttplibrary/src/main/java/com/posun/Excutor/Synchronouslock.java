package com.posun.Excutor;
import com.posun.lighthttplibrary.callback.QlightCallBack;
import com.posun.unit.QlightUnit;
import java.util.Vector;

/**
 * package OKSALES_PDA:com.posun.Excutor.Synchronouslock.class
 * 事件同步锁（默认模式下超出最大任务数量的任务不会进入队列等待，将会被直接释放掉，队列模式才会将任务放入队列等待）
 * 作者：zyq on 2017/2/28 09:59
 * 邮箱：zyq@posun.com
 */
public class Synchronouslock {
    private int max=1;
    private int true_count=0;
    private Vector<QlightCallBack> executers;
    /**
     * 设置允许同时执行的最大任务数量
     * */
    public void setMaxExe(int arg){
        max=arg;
    }
    /**是否为队列模式*/
    public void hasQueue(boolean arg){
        if(arg||executers==null){
            executers=new Vector<>();
        }else if(!arg){
            executers=null;
        }
    }
    /**
     * 执行事件请求
     * */
    public void execute(QlightCallBack callBack){
        boolean arg=canexecute();
        if(!arg&&executers!=null){
            executers.add(callBack);
        }else if(arg){
            callBack.execute(true);
        }
    }
    public boolean canexecute(){
        if(true_count<max){
             true_count++;
            return true;
        }
        return false;
    }
    public void complete(){
        if(true_count>0){
            true_count--;
        }
        if(!QlightUnit.isEmpty(executers)){
            true_count++;
            executers.get(0).execute(true);
            executers.remove(0);
        }
    }
}
