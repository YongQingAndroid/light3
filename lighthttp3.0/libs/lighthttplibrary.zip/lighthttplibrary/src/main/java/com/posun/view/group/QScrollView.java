package com.posun.view.group;

import android.content.Context;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/**
 * 滑动嵌套，不影响AdapterView的VIew复用
 * package OKSALES_PDA:com.posun.view.group.QScrollView.class
 * 作者：zyq on 2017/3/6 16:20
 * 邮箱：zyq@posun.com
 */
public class QScrollView extends NestedScrollView {
    public QScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    @Override
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if(child instanceof RecyclerView){
            RecyclerView recyclerView=(RecyclerView)child;
            recyclerView.setHasFixedSize(true);
            recyclerView.setNestedScrollingEnabled(false);
        }
        super.addView(child, index, params);
    }
    public void SupportLayoutManager(RecyclerView recyclerView){
      RecyclerView.LayoutManager manager= recyclerView.getLayoutManager();
        manager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(manager);
    }
}
