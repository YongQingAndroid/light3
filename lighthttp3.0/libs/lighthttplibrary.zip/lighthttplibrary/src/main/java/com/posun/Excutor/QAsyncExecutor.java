package com.posun.Excutor;
import com.posun.lighthttplibrary.callback.QlightCallBack;

/**
 * Created by zyq on 2017/1/9.
 * 异步处理类
 * 默认使用线程池调度子线程
 */
public class QAsyncExecutor {
    public static void execute(final QWorker qWorker) {
        QExcuter.getSingleInstent().excuteTreadPool(new Runnable() {
            @Override
            public void run() {
                Object object = qWorker.doInBackground();
                QHandlerMsg.postMsgToMainThread(object, new QlightCallBack() {
                    @Override
                    public void execute(Object object) {
                        qWorker.onPostExecute(object);
                    }
                });
            }
        });
    }

    /**
     * 执行子线程任务
     */
    public static abstract class QWorker<T,P> {
        /**
         * 相当于run方法
         */
        protected abstract T doInBackground();

        /**
         * 回调信息到主线程（选用可以不实现）
         */
        protected void onPostExecute(T data) {
        }
        /**
         * 用于同步修改状态例如进度条
         * */
        protected final void publishProgress(P arg){
            if(!(Thread.currentThread().getName().equalsIgnoreCase("main"))){
             QHandlerMsg.postMsgToMainThread(arg, new QlightCallBack() {
                 @Override
                 public void execute(Object object) {
                     onProgressUpdate((P) object);
                 }
             });
            }else{
                onProgressUpdate(arg);
            }
        }
        /**
         * 用于同步修改状态例如进度条等（选用可以不实现）
         * */
        protected void onProgressUpdate(P arg) {}
    }
}
