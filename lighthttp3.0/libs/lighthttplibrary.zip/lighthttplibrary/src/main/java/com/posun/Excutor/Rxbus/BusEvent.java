package com.posun.Excutor.Rxbus;

/**
 * Rxbus事件封装类
 */
public class BusEvent<T> {
    private Integer flage;
    private T Msg;

    public Integer getFlage() {
        return flage;
    }

    public BusEvent setFlage(Integer flage) {
        this.flage = flage;
        return this;
    }

    public T getMsg() {
        return Msg;
    }

    public BusEvent setMsg(T msg) {
        Msg = msg;
        return this;
    }
}
