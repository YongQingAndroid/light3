package com.posun.view.text;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.EditText;

/**
 * 适用于内嵌listview时焦点混乱
 * package OKSALES_PDA:com.posun.view.QEditext.class
 * 作者：zyq on 2017/3/7 17:34
 * 邮箱：zyq@posun.com
 */
public class QFocusEditext extends EditText{
    private boolean move=false;
    public QFocusEditext(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    public QFocusEditext(Context context) {
        super(context);
        init();
    }
    private void init() {
        this.clearFocus();
        this.setFocusable(false);
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                move=false;
                break;
            case MotionEvent.ACTION_MOVE:
                move=true;
                break;
            case MotionEvent.ACTION_UP:
                if(!move&&!this.isFocused()){
                    this.setFocusable(true);
                    this.setFocusableInTouchMode(true);
                    this.requestFocus();
                }
                break;
        }
        return super.onTouchEvent(event);
    }
}
