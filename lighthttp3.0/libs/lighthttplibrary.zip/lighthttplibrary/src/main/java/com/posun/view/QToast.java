package com.posun.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.posun.unit.QlightUnit;
import com.posun.view.ios.IOSDrawable;
/**
 * package OKSALES_PDA:com.posun.view.QToast.class
 * 作者：zyq on 2017/3/6 17:39
 * 邮箱：zyq@posun.com
 */
public class QToast extends Toast{
    public QToast(Context context) {
        super(context);
        init();
    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void init() {
        super.setGravity(Gravity.CENTER,0,-80);
    }
    public void setContentView(View view){
        view.setPadding(20,5,20,5);
        super.setView(view);
    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static QToast makeText(Context context, CharSequence value, int duration){
          QToast qToast=new QToast(context);
          LinearLayout content=new LinearLayout(context);
          content.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));
          content.setPadding(20,5,20,5);
          content.setBackground(new IOSDrawable(Color.BLACK,150,5));
          TextView text=new TextView(context);
          text.setText(value);
          text.setGravity(Gravity.CENTER);
          text.setMinHeight(QlightUnit.dip2px(context,80));
          text.setMinWidth(QlightUnit.dip2px(context,130));
          text.setTextColor(Color.WHITE);
//        int size=QlightUnit.dip2px(context,10);
//        text.setTextSize(size);
          content.addView(text);
          qToast.setContentView(content);
          qToast.setDuration(duration);
          return qToast;
    }
}
