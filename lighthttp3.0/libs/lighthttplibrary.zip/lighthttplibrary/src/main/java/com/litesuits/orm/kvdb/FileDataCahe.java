package com.litesuits.orm.kvdb;

public interface FileDataCahe {
	
}
