package com.resources;

/**
 * Created by dell on 2016/8/9.
 */
public interface EdtextInterface {
    public String getViewText();
    public void setViewText(String value);
}
