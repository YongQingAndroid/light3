package com.resources;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.posun.unit.QlightUnit;
import com.posun.view.ios.IOSDrawable;
import com.posun.view.picker.WheelPicker;
import com.resources.bean.CityBean;
import com.resources.bean.DataString;
import java.util.ArrayList;
import java.util.List;

/**
 * package OKSALES_PDA:com.resources.CityPIcker.class
 * 作者：zyq on 2017/3/7 12:41
 * 邮箱：zyq@posun.com
 */
public class CityPIcker extends LinearLayout{
    private LinearLayout IOSContent;
    private TextView bottom;
    private LinearLayout.LayoutParams pickerLp;
    private int color= Color.parseColor("#1E82FF");;
    private WheelPicker[] pickers=new WheelPicker[3];
    private State[] states;
    private List<CityBean> data;
    private List<CityBean.City> Citys;
    private int city_point=0;
    private int area_point=0;
    public CityPIcker(Context context,State...args) {
        super(context);
        this.states=args;
        init();
    }
    private void praseData(){
        data=new DataString().getJSonData(CityBean.class,getContext());
        addPickerUi();
    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void init() {
        this.setPadding(15,0,15,15);
        this.setOrientation(LinearLayout.VERTICAL);
        IOSContent=new LinearLayout(getContext());
        IOSContent.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        IOSContent.setBackground(new IOSDrawable());
        IOSContent.setPadding(0,20,0,0);
        this.addView(IOSContent);
        bottom=new TextView(getContext());
        LayoutParams bottom_lp=new LayoutParams(LayoutParams.MATCH_PARENT,QlightUnit.dip2px(getContext(),40));
        bottom_lp.setMargins(0,10,0,0);
        bottom.setGravity(Gravity.CENTER);
        bottom.setLayoutParams(bottom_lp);
        bottom.setBackground(new IOSDrawable());
        bottom.setTextColor(color);
        bottom.setText("确定");
        this.addView(bottom);
        pickerLp =new LinearLayout.LayoutParams(0,QlightUnit.dip2px(getContext(),170),1);
        praseData();
    }
    private void setListener(){
        for(int i=0;i<states.length;i++){
            final int point=i;
            pickers[i].setOnItemSelectedListener(new WheelPicker.OnItemSelectedListener() {
                @Override
                public void onItemSelected(WheelPicker picker, Object data, int position) {
                    UpData(states[point],position,String.valueOf(data));
                }
            });
        }
    }
    private void UpData(State state,int position,String value){
          switch (state){
              case PROVINCE:
                  if(QlightUnit.isEmpty(Citys)){
                      return;
                  }
                  pickers[city_point].setData(prasCityValue(data.get(position).getCity()));
                  pickers[city_point].setSelectedItemPosition(0);
                  pickers[area_point].setData(Citys.get(0).getCounty());
                  pickers[area_point].setSelectedItemPosition(0);
                  break;
              case CITY:
                  pickers[area_point].setData(Citys.get(position).getCounty());
                  pickers[area_point].setSelectedItemPosition(0);
                  break;
              case AREA:
                  break;
          }
    }
    private void addPickerUi() {
        if(QlightUnit.isEmpty(states)){
            return;
        }
        for(int i=0;i<states.length;i++){
            states[i].point=i;
            addPickerView(states[i]);
        }
        setListener();
    }
    private void addPickerView(State item){
        switch (item){
            case PROVINCE:
                WheelPicker p_picler=new WheelPicker(getContext(),color);
                p_picler.setLayoutParams(pickerLp);

                pickers[item.point]=p_picler;
                p_picler.setData(praseProvinceValue());
                p_picler.setSelectedItemPosition(0);
                IOSContent.addView(p_picler);
                break;
            case CITY:
                WheelPicker c_picler=new WheelPicker(getContext(),color);
                c_picler.setLayoutParams(pickerLp);
//                c_picler.setCyclic(false);
                c_picler.setData(prasCityValue(data.get(0).getCity()));
                c_picler.setSelectedItemPosition(0);
                city_point=item.point;
                pickers[item.point]=c_picler;
                IOSContent.addView(c_picler);
                break;
            case AREA:
                WheelPicker a_picler=new WheelPicker(getContext(),color);
                a_picler.setLayoutParams(pickerLp);
                a_picler.setCyclic(false);
                a_picler.setData(data.get(0).getCity().get(0).getCounty());
                a_picler.setSelectedItemPosition(0);
                area_point=item.point;
                pickers[item.point]=a_picler;
                IOSContent.addView(a_picler);
                break;
        }
    }
    private List<String> praseProvinceValue(){
        List<String> items=new ArrayList<>();
        for(CityBean bean: data){
            items.add(bean.getName());
        }
        return items;
    }
    private List<String> prasCityValue(List<CityBean.City> args){
        Citys=args;
        List<String> items=new ArrayList<>();
        for(CityBean.City city:args){
            items.add(city.getName());
        }
        return items;
    }
   public enum State{
        PROVINCE(0),
        CITY(0),
        AREA(0);
        int point;
        State(int point){
            this.point=point;
        }
    }
}
