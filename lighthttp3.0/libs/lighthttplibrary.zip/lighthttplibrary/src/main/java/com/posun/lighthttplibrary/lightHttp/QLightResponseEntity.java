package com.posun.lighthttplibrary.lightHttp;

/**
 * Created by dell on 2017/2/7.
 */
public class QLightResponseEntity<T> {
    private String method;
    private T object;
    public QLightResponseEntity(T object, String method){
        this.method=method;
        this.object=object;
    }
    public String getMethod() {
        return method;
    }
    /**
     *  取出回调数据并释放内存空间
     * */
    public T getObject() {
        T thing=object;
        object=null;
        return thing;
    }
}
