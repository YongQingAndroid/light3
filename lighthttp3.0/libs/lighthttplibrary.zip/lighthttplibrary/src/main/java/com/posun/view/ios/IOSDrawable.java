package com.posun.view.ios;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
/**
 * 作者：zyq on 2017/3/3 14:14
 * 邮箱：zyq@posun.com
 */
public class IOSDrawable extends Drawable{
    private Paint mPaint;
    private RectF rectF;
    private int alpha;
    private int arc;
    public IOSDrawable(){
      this(Color.WHITE,220,15);
    }
    public IOSDrawable(int color,int alpha,int arc){
        this.alpha=alpha;
        this.arc=arc;
        mPaint=new Paint();
        mPaint.setColor(color);
        mPaint.setAlpha(alpha);
        mPaint.setAntiAlias(true);
    }
    @Override
    public void draw(Canvas canvas) {
        canvas.drawRoundRect(rectF, arc,arc, mPaint);
    }
    @Override
    public void setBounds(int left, int top, int right, int bottom)
    {
        super.setBounds(left, top, right, bottom);
        rectF = new RectF(left, top, right, bottom);
    }
    @Override
    public void setAlpha(int i) {
        mPaint.setAlpha(i);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return PixelFormat.OPAQUE;
    }

}
