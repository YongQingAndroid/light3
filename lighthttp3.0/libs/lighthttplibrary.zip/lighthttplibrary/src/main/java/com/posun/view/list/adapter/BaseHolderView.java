package com.posun.view.list.adapter;
import android.view.View;
/**
 * Created by dell on 2017/2/15.
 */
public interface BaseHolderView<T> {
    void init(T obj);
    View getView();
}
