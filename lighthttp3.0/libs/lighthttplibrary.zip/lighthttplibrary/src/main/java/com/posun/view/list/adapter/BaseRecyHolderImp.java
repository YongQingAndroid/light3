package com.posun.view.list.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by zyq on 2017/1/10.
 * 通用适配器Holder接口
 */
public interface BaseRecyHolderImp<T> {
    void BindView(T itemDate, int position);
    void bindEvent(View rootView, View.OnClickListener listener);
    void bindParentHolder(RecyclerView.ViewHolder holder);
    void addOnitemClickListener(QBaseRecyHolder.ItemClickListener clickListener);
}
