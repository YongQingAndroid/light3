package com.locat;

import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * package kotlinTest:com.locat.aaaaaa.class
 * 作者：zyq on 2017/7/10 12:12
 * 邮箱：zyq@posun.com
 */
public class LightLocationManager {
    public static final int WGS84 = 0, GCJ02 = 1, BD09 = 2;
    public String key = "7716cb7160daa0d0fdfe3641ff3af78b";
    private WeakReference<LightLocationListener> listner;
    private LocationManager locationManager;
    private LocationListener mLocationListener;

    public void setGaoDeMapKey(String mykey) {
        key = mykey;
    }

    public void getLocation(LightLocationListener callback) throws Exception {
        getLocation((Application) Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null, (Object[]) null), callback, GCJ02);
    }

    public void getLocation(Application application, LightLocationListener callback, final int GSPDEVIATION) {
        Location location = null;
        String reason = null;
        boolean isgps = true;
        listner = new WeakReference<>(callback);

        locationManager = (LocationManager) application.getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(application, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(application, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            callback.fail("定位权限没有开启，或者gps信号异常");
            return;
        }
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        }
        if (location == null) {
            location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            isgps = false;
            if (location == null) {
                if (TextUtils.isEmpty(reason)) {
                    reason = "定位失败";
                }
                callback.fail(reason);
                mLocationListener = new LocationListener() {

                    @Override
                    public void onStatusChanged(String provider, int status,
                                                Bundle extras) {
                    }

                    @Override
                    public void onProviderEnabled(String provider) {

                    }

                    @Override
                    public void onProviderDisabled(String provider) {
                    }

                    @Override
                    public void onLocationChanged(Location location) {
                        if (listner.get() != null) {
                            Gps gps = getLocation(GSPDEVIATION, location);
                            listner.get().location(gps);
                            Geocoding(gps, listner.get(), true);
                        }
                    }
                };
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                        3000, 8, mLocationListener);
                return;
            }
        }
        Gps gps = getLocation(GSPDEVIATION, location);
        callback.location(gps);
        Geocoding(gps, callback, isgps);
    }

    public void removeRegister(Application context) {
        if (mLocationListener == null)
            return;
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.removeUpdates(mLocationListener);
    }

    private Gps getLocation(int GSPDEVIATION, Location location) {
        Gps gps = null;
        if (GSPDEVIATION == WGS84) {
            gps = new Gps(location.getLatitude(), location.getLongitude());
        } else if (GSPDEVIATION == GCJ02) {
            gps = PositionUtil.gps84_To_Gcj02(location.getLatitude(), location.getLongitude());
        } else if (GSPDEVIATION == BD09) {
            gps = PositionUtil.gps84_To_Gcj02(location.getLatitude(), location.getLongitude());
            gps = PositionUtil.gcj02_To_Bd09(gps.getWgLat(), gps.getWgLat());
        }
        return gps;
    }

    public void Geocoding(final Gps gps, final LightLocationListener callback, final boolean isgps) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://restapi.amap.com/v3/geocode/regeo?key=" + key + "&location=" + gps.getWgLon() + "," + gps.getWgLat() + "");
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    if (200 == urlConnection.getResponseCode()) {
                        InputStream is = urlConnection.getInputStream();
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        byte[] buffer = new byte[1024];
                        int len = 0;
                        while (-1 != (len = is.read(buffer))) {
                            baos.write(buffer, 0, len);
                            baos.flush();
                        }
                        String obj = baos.toString("utf-8");
                        if (!TextUtils.isEmpty(obj)) {
                            JSONObject jb = new JSONObject(obj);
                            String adress = jb.getJSONObject("regeocode").optString("formatted_address");
                            if (isgps) {
                                adress = adress + "[GPS]";
                            } else {
                                adress = adress + "[WIFI NET]";
                            }
                            android.os.Handler hadler = new android.os.Handler(Looper.getMainLooper()) {
                                @Override
                                public void handleMessage(Message msg) {
                                    callback.locationName((String) msg.obj);
                                }
                            };
                            hadler.sendMessage(hadler.obtainMessage(1, adress));

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static double getDistance(double lng1, double lat1, double lng2, double lat2) {
        double distance = 0.0D;
        double dLat = (lat2 - lat1) * 3.141592653589793D / 180.0D;
        double dLon = (lng2 - lng1) * 3.141592653589793D / 180.0D;
        distance = Math.sin(dLat / 2.0D) * Math.sin(dLat / 2.0D) + Math.cos(lat1 * 3.141592653589793D / 180.0D) * Math.cos(lat2 * 3.141592653589793D / 180.0D) * Math.sin(dLon / 2.0D) * Math.sin(dLon / 2.0D);
        distance = 2.0D * Math.atan2(Math.sqrt(distance), Math.sqrt(1.0D - distance)) * 6378.137D;
        return (double) Math.round(distance * 1000.0D) / 1000.0D;
    }

    /************实时位置*********************
     //    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, locationListener);*/
}
