package com.posun.view.list.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.posun.lighthttplibrary.annotation.QBaseAdapter;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  .--,       .--,
 * ( (  \.---./  ) )
 *  '.__/o   o\__.'
 *     {=  ^  =}
 *      >  -  <
 *     /       \
 *    //       \\
 *   //|   .   |\\
 *   "'\       /'"_.-~^`'-.
 *      \  _  /--'         `
 *    ___)( )(___
 *   (((__) (__)))    高山仰止,景行行止.虽不能至,心向往之。*/

public class QAdapterManager{
    public static QAdapterManager getInstence() {
        return new QAdapterManager();
    }
    /***
     * @param beanType 集合bean对象
     * @param data 数据集合
     * */
    public BaseRecyAdapter getAdapter(List<?> data, Class beanType) {
        Annotation mAnnotation = beanType.getAnnotation(QBaseAdapter.class);
        QBaseAdapter adpter = (QBaseAdapter) mAnnotation;
        BaseRecyAdapter adapter = new BaseRecyAdapter(data, adpter.Holder(), adpter.LayoutId());
        return adapter;
    }
    /***
     * @param beanType Holder对象
     * @param data 数据集合
     * */
    public BaseRecyAdapter getAdapterPraseHolder(List<?> data, Class<? extends QBaseRecyHolder> beanType) {
        Annotation mAnnotation = beanType.getAnnotation(QBaseAdapter.class);
        QBaseAdapter adpter = (QBaseAdapter) mAnnotation;
        BaseRecyAdapter adapter = new BaseRecyAdapter(data, beanType, adpter.LayoutId());
        return adapter;
    }
    /***
     * @param beanType 集合bean对象
     * @param data 数据集合
     * */
    public BaseHeadRecyAdapter getAdapter_withHeard(List<?> data, Class beanType, View view) {
        Annotation mAnnotation = beanType.getAnnotation(QBaseAdapter.class);
        QBaseAdapter adpter = (QBaseAdapter) mAnnotation;
        BaseHeadRecyAdapter adapter = new BaseHeadRecyAdapter(data, adpter.Holder(), adpter.LayoutId());
        adapter.add_HeardView(view);
        return adapter;
    }
    /***
     * @param beanType 集合bean对象
     * @param data 数据集合
     * @param listener 绑定监听器建议舒勇Activity里面定义监听器,Holder复写SetTag
     * */
    public BaseRecyAdapter getAdapter(List<?> data, Class beanType, View.OnClickListener listener) {
        Annotation mAnnotation = beanType.getAnnotation(QBaseAdapter.class);
        QBaseAdapter adpter = (QBaseAdapter) mAnnotation;
        BaseRecyAdapter adapter = new BaseRecyAdapter(data, adpter.Holder(), adpter.LayoutId());
        adapter.bindEvent(listener);
        return adapter;
    }
    /**
     * 通用adapter构造器
     *
     * */

    public static class Builder {
        Map<Integer, Integer> Views;
        Map<Integer, Class> Holders;
        BaseRecyAdapter.TypeFace typeFace;

        public Builder() {
            Views = new HashMap<>();
            Holders = new HashMap<>();
        }
        /***
         * @param typeFace 返回视图类型
         * */
        public Builder setViewType(BaseRecyAdapter.TypeFace typeFace) {
            this.typeFace = typeFace;
            return this;
        }
        /**
         * 视图类型和视图的对应关系
         * */
        public Builder setViews(int type, int view_id, Class<?> classname) {
            Views.put(type,view_id);
            Holders.put(type,classname);
            return this;
        }
        /**
         *  生成adpater
         * @param data 数据集合
         * */
        public  RecyclerView.Adapter creat(List<?> data){
            BaseRecyAdapter adapter = new BaseRecyAdapter(data);
            adapter.setViewType(typeFace);
            adapter.setViews(Views,Holders);
            return adapter;
        }
    }
    /**
     * bean对象被多个视图同时绑定时，需要使用这个构造器获取adapter
     * */
    public static class MultiplexBuilder{
        private boolean isHeard=false;
        private Class<?> bean_class,HolderClass ;
        private HolderId Holder_id;
        private int Layout_id;
        private View headView;
        public MultiplexBuilder setHeadView(View headView) {
            this.headView = headView;
            this.isHeard=true;
            return this;
        }

        public MultiplexBuilder setBean_class(Class<?> bean_class) {
            this.bean_class = bean_class;
            return this;
        }

        public MultiplexBuilder setHolder_id(HolderId holder_id) {
            Holder_id = holder_id;
            return this;
        }

        public MultiplexBuilder setHolderClass(Class<?> holderClass) {
            HolderClass = holderClass;
            return this;
        }

        public MultiplexBuilder setLayout_id(int layout_id) {
            Layout_id = layout_id;
            return this;
        }

        /**
         *  生成adpater
         * @param data 数据集合
         * */
        public RecyclerView.Adapter  creat(List<?> data){
             if(HolderClass!=null){
                 if(isHeard){
                     return   new BaseHeadRecyAdapter(data,HolderClass,Layout_id,headView);
                 }else{
                     return  new BaseRecyAdapter(data,HolderClass,Layout_id);
                 }
             }
            if(isHeard){
              return QAdapterManager.getInstence().getAdapter_withHeard(data,bean_class,headView);
            }else{
                return QAdapterManager.getInstence().getAdapter(data,bean_class);
            }
        }
    }
    public  enum HolderId{
        ONE,DOUBLE,TRIPLE ,QUADRA,PENTA;
    }
}
