package com.posun.Excutor.Rxbus;

/**
 * Created by dell on 2017/1/6.
 */
public interface OnScanCallback {
    void OnScan(Object object);
}
