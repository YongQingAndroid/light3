package com.posun.view.ios;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.posun.unit.QlightUnit;
import com.posun.view.QDialog;
import com.posun.view.list.MaterialProgressDrawable;

/**
 * package OKSALES_PDA:com.posun.view.ios.IOSProgressDiaLog.class
 * 作者：zyq on 2017/3/8 16:45
 * 邮箱：zyq@posun.com
 */
public class IOSProgressDiaLog extends QDialog {
    public IOSProgressDiaLog(Context context) {
        super(context);
        initIOSProgressDiaLog();
    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void initIOSProgressDiaLog() {
        int height= QlightUnit.dip2px(getContext(),100);
        LinearLayout viewroot = new LinearLayout(getContext());
        viewroot.setGravity(Gravity.CENTER);
        LinearLayout IOScontent = new LinearLayout(getContext());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(height,height);
        IOScontent.setLayoutParams(lp);
        IOScontent.setBackground(new IOSDrawable(Color.BLACK,100,15));
        viewroot.addView(IOScontent);
        IOScontent.setPadding(20,20,20,20);
        initImgeView(IOScontent);
        super.setGravity(QGriavty.CENTER);
        super.setContentView(viewroot);
    }
    private void initImgeView(LinearLayout ioScontent) {
        ImageView img=new ImageView(getContext());
        MaterialProgressDrawable mProgress = new MaterialProgressDrawable(getContext(), img);
        mProgress.setColorSchemeColors(Color.RED, Color.BLACK,Color.YELLOW,Color.GREEN);
        mProgress.setAlpha(255);
        mProgress.setStartEndTrim(0f, 0.8f);
        mProgress.setArrowScale(1f);
        mProgress.setProgressRotation(0.9f);
        mProgress.start();
        img.setImageDrawable(mProgress);
        img.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        ioScontent.addView(img);
    }
}
