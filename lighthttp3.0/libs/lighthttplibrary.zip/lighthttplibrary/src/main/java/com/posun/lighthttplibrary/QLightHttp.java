package com.posun.lighthttplibrary;

import com.alibaba.fastjson.JSON;
import com.posun.Excutor.QHandlerMsg;
import com.posun.lighthttplibrary.callback.QlightCallBack;
import com.posun.lighthttplibrary.lightHttp.QCall;
import com.posun.lighthttplibrary.lightHttp.QLightResponseEntity;
import com.posun.Excutor.QExcuter;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Type;
import java.util.List;

import okhttp3.Call;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * This network framework is based on the production of okhttp
 * Network framework free open source, and the final right to interpret the author.
 * The author will go regularly to update the business code, but no obligation to notify the user.
 * My open source community account is fengling136
 * Welcome attention
 * Thanks for your use
 * the power by ZYQ
 */
public class QLightHttp {
    private Builder builder;
    public static String TAG = "lighthttp";

    private QLightHttp(Builder builder) {
        this.builder = builder;
    }

    /**
     * Dynamic proxy non object class is achieved by using the default implementation method of dynamic proxy class.
     */
    public <T> T creat(Class<T> myclass) {
        InvocationHandler handler = new PraseJsonHandler(builder);
        Object ob = java.lang.reflect.Proxy.newProxyInstance(myclass.getClassLoader(), new Class<?>[]{myclass}, handler);
        return (T) ob;
    }

    public static final class Builder {
        private String msrc;
        private LightHttpCover cover;
        private LightAdapterCover adapterCover;
        private Request.Builder builder;
        private Headers.Builder hbuilder;

        public Builder src(String src) {
            this.msrc = src;
            return this;
        }

        public Builder setHeader(String key, String value) {
            if (hbuilder == null) {
                hbuilder = new Headers.Builder();
            }
            hbuilder.set(key, value);
            return this;
        }

        public Headers.Builder getHeaders() {
            return hbuilder;
        }

        protected Request.Builder getBuilder() {
            return builder;
        }

        public Builder setBuilder(Request.Builder builder) {
            this.builder = builder;
            return this;
        }

        public LightAdapterCover getAdapterCover() {
            return adapterCover;
        }

        public Builder addAdapterCover(LightAdapterCover adapterCover) {
            this.adapterCover = adapterCover;
            return this;
        }

        public Builder addResultCover(LightHttpCover cover) {
            this.cover = cover;
            return this;
        }

        public QLightHttp build() {
            return new QLightHttp(this);
        }

        protected LightHttpCover getCover() {
            return cover;
        }

        protected String getMsrc() {
            return msrc;
        }

    }
    public static class SimpleRequest {
        private Headers.Builder hbuilders=new Headers.Builder();
        public SimpleRequest setHeard(String key,String value){
            hbuilders.set(key, value);
            return this;
        }
        public <T>T get(String src,Class<T>clazz) throws Exception{
          return JSON.parseObject(new OkHttpClient().newCall(new Request.Builder().url(src).get().headers(hbuilders.build()).build()).execute().body().string(),clazz);
        }
        public <T> void  get(final String src, final Class<T> clazz, final QCall<QLightResponseEntity<T>> call) throws Exception{
            QExcuter.getSingleInstent().excuteTreadPool(new Runnable() {
                @Override
                public void run() {
                    try {
                        Request mRequest= new Request.Builder().url(src).get().headers(hbuilders.build()).build();
                        Call hcall=new OkHttpClient().newCall(mRequest);
                        QLightResponseEntity entity= new QLightResponseEntity(JSON.parseObject(hcall.execute().body().string(),clazz),mRequest.method());
                        QHandlerMsg.postMsgToMainThread(entity, new QlightCallBack() {
                            @Override
                            public void execute(Object object) {
                                call.onSuccess((QLightResponseEntity<T>)object);
                            }
                        });
                    } catch (Exception e) {
                        QHandlerMsg.postMsgToMainThread(e, new QlightCallBack() {
                            @Override
                            public void execute(Object object) {
                                call.onFaile((Exception)object);
                            }
                        });
                    }
                }
            });
        }
        public <T> void  getList(final String src, final Class<T> clazz, final QCall<QLightResponseEntity<List<T>>> call) throws Exception{
            QExcuter.getSingleInstent().excuteTreadPool(new Runnable() {
                @Override
                public void run() {
                    try {
                        Request mRequest= new Request.Builder().headers(hbuilders.build()).url(src).get().build();
                        Call hcall=new OkHttpClient().newCall(mRequest);
                        QLightResponseEntity entity= new QLightResponseEntity(JSON.parseArray(hcall.execute().body().string(),clazz),mRequest.method());
                        QHandlerMsg.postMsgToMainThread(entity, new QlightCallBack() {
                            @Override
                            public void execute(Object object) {
                                call.onSuccess((QLightResponseEntity<List<T>>)object);
                            }
                        });
                    } catch (Exception e) {
                        QHandlerMsg.postMsgToMainThread(e, new QlightCallBack() {
                            @Override
                            public void execute(Object object) {
                                call.onFaile((Exception)object);
                            }
                        });
                    }
                }
            });
        }
        public void post(final String src, final Object object, final QCall<String> call) throws Exception{
            QExcuter.getSingleInstent().excuteTreadPool(new Runnable() {
                @Override
                public void run() {
                    try {
                        RequestBody mRequestBody=RequestBody.create(MediaType.parse("application/json; charset=utf-8"),JSON.toJSONString(object));
                        call.onSuccess(new OkHttpClient().newCall(new Request.Builder().url(src).headers(hbuilders.build()).post(mRequestBody).build()).execute().body().string());
                    } catch (Exception e) {
                        e.printStackTrace();
                        call.onFaile(e);
                    }
                }
            });


        }
        public String post(String src,Object object) throws Exception{
            RequestBody mRequestBody=RequestBody.create(MediaType.parse("application/json; charset=utf-8"),JSON.toJSONString(object));
            return new OkHttpClient().newCall(new Request.Builder().url(src).headers(hbuilders.build()).post(mRequestBody).build()).execute().body().string();
        }
    }
    public interface LightHttpCover<T> {
        T just(Response mObject, Type type, Object expandValue) throws Exception;
    }
    public interface LightAdapterCover<M> {
        M adapter(Type type, LightHttpRequest mRequest);
    }
}
