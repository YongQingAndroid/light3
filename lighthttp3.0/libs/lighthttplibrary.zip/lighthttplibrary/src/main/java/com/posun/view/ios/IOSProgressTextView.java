package com.posun.view.ios;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import com.posun.lighthttplibrary.R;

/**
 * 作者：zyq on 2017/3/10 15:38
 * 邮箱：zyq@posun.com
 */
public class IOSProgressTextView extends View {
    private Paint mPaint;
    private int mProgress = 0;
    private int mMax = 100;
    private int mCorner = 5, mBackgroundColor, size=30;
    private String text="数据加载中....";
    public IOSProgressTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.progressText);
        text=a.getString( R.styleable.progressText_text);
        mBackgroundColor=a.getColor(R.styleable.progressText_color,Color.BLUE);
        a.recycle();
        mPaint = new Paint();
        mPaint.setColor(Color.BLUE);
        mPaint.setTextSize(size);
        mPaint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF oval = new RectF(0, 0, getWidth(), getHeight());
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(mBackgroundColor);
        canvas.drawRoundRect(oval, mCorner, mCorner, mPaint);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setColor(mBackgroundColor);
        oval = new RectF(0, 0, (getWidth() * mProgress) / mMax, getHeight());
        canvas.drawRoundRect(oval, mCorner, mCorner, mPaint);
        mPaint.setTextAlign(Paint.Align.CENTER);

        Paint.FontMetrics fontMetrics = mPaint.getFontMetrics();
        float top = fontMetrics.top;
        float bottom = fontMetrics.bottom;//为基线到字体下边框的距离,即上图中的bottom
        int baseLineY = (int) (getHeight()/2 - top/2 - bottom/2);//基线中间点的y轴计算公式
        canvas.drawText(text,getWidth()/2,baseLineY,mPaint);
        mPaint.setColor(Color.WHITE);
        canvas.clipRect(oval);
        canvas.drawText(text,getWidth()/2,baseLineY,mPaint);
    }

    public void setprogress(int arg) {
            mProgress+=arg;
        if (mProgress > mMax)
            mProgress = 0;
            invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}
