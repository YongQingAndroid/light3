package com.posun.view.list.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import java.util.List;
import java.util.Map;

/**
 * Created by zyq on 2017/1/10.
 */
public abstract class QBaseRecyHolder<M> extends RecyclerView.ViewHolder implements BaseRecyHolderImp<M> {
    private RecyclerView.ViewHolder holder;
    private ItemClickListener clickListener;
    private Map<String,Object> stringObjectMap;
    protected List<M> msource;
    public QBaseRecyHolder(View itemView, List<M> msource,Map<String,Object> stringObjectMap) {
        super(itemView);
        this.msource=msource;
        this.stringObjectMap=stringObjectMap;
    }
    protected int getPosion() {
        return holder.getAdapterPosition();
    }

    @Override
    public void bindParentHolder(RecyclerView.ViewHolder holder) {
        this.holder = holder;
    }

    /**
     * 绑定点击事件可在bindOnItemClicklistener 中回调
     */
    public void setOnItemClickLister(View view) {
        if (clickListener == null) {
            return;
        }
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickListener.OnitemClick(v, holder.getAdapterPosition());
            }
        });
    }
    /**
     * 绑定activity当前注册的事件监听器
     * **/
    @Override
    public void addOnitemClickListener(ItemClickListener clickListener) {
        this.clickListener = clickListener;
    }
    /**
     * item事件回调
     * */
    public static interface ItemClickListener {
        void OnitemClick(View v, int position);
    }
    /**
     * 获取BaseRecyAdapter生命周期内的全局变量
     * */
    protected <J>J getGlobalValue(String key){
        if(stringObjectMap.containsKey(key)){
              return (J)stringObjectMap.get(key);
        }
        return null;
    }
    /**
     * 赋值一个BaseRecyAdapter生命周期内的全局变量
     * */
    protected void setGlobalValue(String key,Object object){
        stringObjectMap.put(key, object);
    }
    /**
     * 初始化一个BaseRecyAdapter生命周期内的全局变量
     * */
    protected void InItGlobalValue(String key,Object object){
        if(stringObjectMap.containsKey(key)){
            return;
        }
        stringObjectMap.put(key, object);
    }
}
