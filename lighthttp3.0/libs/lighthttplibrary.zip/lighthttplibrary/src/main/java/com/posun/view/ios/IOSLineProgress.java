 package com.posun.view.ios;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.ColorInt;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by qing on 2017/3/11.
 */

public class IOSLineProgress extends View {
    private int max=100;
    private int progress=0;
    private int color=Color.BLUE;
    public IOSLineProgress(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    public IOSLineProgress(Context context) {
        super(context);
        initIOSLineProgress();
    }

    private void initIOSLineProgress() {

    }
    public void setlinecolor(@ColorInt int color){
        this.color=color;
    }
    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint=new Paint();
        paint.setTextSize(15);
        String text=String.valueOf((progress*100)/max)+"%";
        float space=paint.measureText(text)+4;
        int hight=getHeight() /2;
        int Width=((getWidth()*progress)/max);
        paint.setColor(color);
        paint.setStrokeWidth(2);
        canvas.drawLine(Width,hight,getWidth(),hight,paint);
        paint.setStrokeWidth(5);
        canvas.drawLine(0,hight,Width-space,hight,paint);
        canvas.drawText(text,Width-space+2,hight+5,paint);
//        this.progress+=1;
//        if(progress>max){
//            progress=0;
//        }
//        postInvalidateDelayed(50);
    }
    public void setprogress(int arg){
        this.progress+=arg;
         if(progress>max){
             progress=0;
         }
        invalidate();
    }

}
