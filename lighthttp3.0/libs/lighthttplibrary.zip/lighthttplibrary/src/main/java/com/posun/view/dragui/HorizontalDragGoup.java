package com.posun.view.dragui;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * Created by zyq on 2017/2/7.
 * 滑动菜单
 *  适用于listview，RecyclerView，gridview，以及任意布局嵌套
 */
public class HorizontalDragGoup extends FrameLayout {
    private float startx=0;
    private float startm=0;
    private LayoutParams layoutParams;
    private boolean iswidth=true;
    private View topview;
    private DrageMeun mDrageMeun;
    public HorizontalDragGoup(Context context) {
        super(context);
        this.setBackgroundColor(Color.GRAY);
        LayoutParams layoutParamsp=new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
        setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT));
        layoutParams=new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
        LinearLayout below=new LinearLayout(getContext());
        below.setGravity(Gravity.RIGHT);
        mDrageMeun=new DrageMeun(context);
        below.addView(mDrageMeun);
        super.addView(below,layoutParamsp);
    }
    @Override
    public void addView(View child) {
        super.addView(child);
         this.topview=child;
         child.setLayoutParams(layoutParams);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                return true;
            case MotionEvent.ACTION_MOVE:
                return false;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startx=ev.getRawX();
                startm=layoutParams.leftMargin;
                 return true;
            case MotionEvent.ACTION_MOVE:
                int move=(int)(startm+ev.getRawX()-startx);
                    layoutParams.setMargins(getMargin(move),0,0,0);
                    topview.setLayoutParams(layoutParams);
                break;
            case MotionEvent.ACTION_UP:
              break;
        }
        return super.onTouchEvent(ev);
    }
    private int getMargin(int move){
        if(move>0){
            return 0;
        }
        if(Math.abs(move)<mDrageMeun.openwidth){
            return move;
        }
        return -mDrageMeun.openwidth;
    }
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if(iswidth){
            iswidth=!iswidth;
            layoutParams.width= MeasureSpec.getSize(widthMeasureSpec);
            topview.setLayoutParams(layoutParams);
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}
