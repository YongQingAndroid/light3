package com.litesuits.orm;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.litesuits.orm.db.DataBaseConfig;
import com.litesuits.orm.db.assit.SQLiteHelper;
import com.posun.lighthttplibrary.BuildConfig;
import com.posun.unit.QlightUnit;
import java.util.List;
public class QOrmManager implements SQLiteHelper.OnUpdateListener {
  public LiteOrm mLiteOrm;
  private static QOrmManager self;
  private QOrmManager(){
  }
  public static synchronized  QOrmManager getInstance() {
    if (self == null)
      self = new QOrmManager();
    return self;
  }
  @Override public void onUpdate(SQLiteDatabase sqLiteDatabase, int i, int i1) {
  }
  public void dbInit(Context context){
    this.dbInit(context,"help.db");
  }
  public void dbInit(Context context,String dbname){
    DataBaseConfig config = new DataBaseConfig(context,dbname);
    config.dbVersion = 1;
    config.onUpdateListener = this;
//    config.debugged = BuildConfig.DEBUG;
    mLiteOrm = LiteOrm.newSingleInstance(config);
  }
  public void save(Object o) {
    if (o == null) {
      return;
    }

    mLiteOrm.save(o);
  }

  public void save(List<?> collection) {
    if (QlightUnit.isEmpty(collection)) {
      return;
    }
    mLiteOrm.save(collection);
  }

  public  void delete(Class<?> tClass) {
    if (tClass == null) {
      return;
    }

    mLiteOrm.delete(tClass);
  }

  public <T> List<T> queryAll(Class<T> tClass) {
    if (tClass == null) {
      return null;
    }
    return mLiteOrm.query(tClass);
  }

}