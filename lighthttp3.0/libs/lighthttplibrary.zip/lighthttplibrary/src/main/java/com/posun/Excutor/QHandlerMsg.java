package com.posun.Excutor;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.posun.lighthttplibrary.callback.QlightCallBack;

/**
 * Created by dell on 2017/1/9.
 * 2017/2/28解决内存泄露
 * 消息传递工具
 */
 public class QHandlerMsg {
 public static   Handler handler;
  public static void postMsgToMainThread(Object object,final QlightCallBack mcallBack){
      if(handler==null){
          new Handler(Looper.getMainLooper()){
              @Override
              public void handleMessage(Message msg) {
                  if(msg!=null){
                      mcallBack.execute(msg.obj);
                  }
                  super.handleMessage(msg);
              }
          };
      }
      handler.sendMessage(handler.obtainMessage(1,object));
  }
}
