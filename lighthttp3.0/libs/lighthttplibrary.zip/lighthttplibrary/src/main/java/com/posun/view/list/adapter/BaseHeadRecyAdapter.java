package com.posun.view.list.adapter;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.lang.reflect.Constructor;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/1/10.
 */
public final class BaseHeadRecyAdapter extends RecyclerView.Adapter {
    private int layout_id;
    private Class holder_Class = Holder.class;
    private List<?> data;
    private TypeFace callback;
    private boolean isSingleType=true;
    private View Heard_view;
    private Map<Integer,Integer> Views;
    private Map<Integer,Class> Holders;
    private View.OnClickListener listener;
    private QBaseRecyHolder.ItemClickListener itemClickListener;
    private final int heardType=-5;
    public BaseHeadRecyAdapter(List<?> data, Class holder_Class, int layout_id) {
        this.data = data;
        this.holder_Class = holder_Class;
        bindLayout(layout_id);
    }
    public BaseHeadRecyAdapter(List<?> data, Class holder_Class, int layout_id,View Heard_view) {
        this.data = data;
        this.holder_Class = holder_Class;
        this.Heard_view=Heard_view;
        bindLayout(layout_id);
    }
    public BaseHeadRecyAdapter(List<?> data) {
        this.data = data;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
         if(viewType==heardType){
          return new HeardHolder(Heard_view);
         }
        if(isSingleType){
            View rootView = LayoutInflater.from(parent.getContext()).inflate(layout_id, parent, false);
            return new Holder(rootView,holder_Class);
        }else{
            View rootView = LayoutInflater.from(parent.getContext()).inflate(Views.get(viewType), parent, false);
            return new Holder(rootView,Holders.get(viewType));
        }
    }
    public void add_HeardView(View heard_view){
         this.Heard_view=heard_view;
    }
    @Override
    public int getItemViewType(int position) {
         if(position==0){
             return heardType;
         }
        position--;
        if(!isSingleType&&callback!=null){
          return  callback.getItemType(position);
        }
        return super.getItemViewType(position);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(position==0){
            return;
        }
        position--;
        Holder viewholder=(Holder)holder;
        viewholder.baseRecyHolderImp.BindView(data.get(position),position);
    }

    public void bindLayout(int layout_id) {
        this.layout_id = layout_id;
    }

    @Override
    public int getItemCount() {
        if(data==null||data.size()<1){
            return 1;
        }
        return data.size()+1;
    }
    protected static class HeardHolder extends RecyclerView.ViewHolder{

        public HeardHolder(View itemView) {
            super(itemView);
        }
    }
    public class Holder extends RecyclerView.ViewHolder {
        protected BaseRecyHolderImp baseRecyHolderImp;

        public Holder(View itemView,Class<?> classname) {
            super(itemView);
            try {
                Constructor constructor = classname.getDeclaredConstructor(View.class);
                constructor.setAccessible(true);
                baseRecyHolderImp = (BaseRecyHolderImp) constructor.newInstance(new Object[]{itemView});
                baseRecyHolderImp.addOnitemClickListener(itemClickListener);
                baseRecyHolderImp.bindParentHolder(Holder.this);
                baseRecyHolderImp.bindEvent(itemView,listener);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @Deprecated
    public void bindOnItemClicklistener(QBaseRecyHolder.ItemClickListener itemClickListener){
        this.itemClickListener=itemClickListener;
    }
    @Deprecated
    public void bindEvent(View.OnClickListener listener){
        this.listener=listener;
    }
    public void  setViewType(TypeFace callback){
       this.callback=callback;
       isSingleType=false;
    }
    public void setViews(Map<Integer,Integer> mviews,Map<Integer,Class> holders){
        Holders=holders;
        Views=mviews;
    }
    public static interface TypeFace{
        int getItemType(int position);
    }
}
