package com.posun.mvpframework.presenter;

/**
 * Created by dell on 2017/1/17.
 */
public interface BasePresenterInterface{
    void free();
}
