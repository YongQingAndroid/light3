package com.posun.lighthttplibrary.annotation;

		import android.support.v7.widget.RecyclerView;

		import com.posun.view.list.adapter.QAdapterManager;

		import java.lang.annotation.Documented;
		import java.lang.annotation.ElementType;
		import java.lang.annotation.Retention;
		import java.lang.annotation.RetentionPolicy;
		import java.lang.annotation.Target;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
/**
 * the power by ZYQ
 */
public @interface QBaseAdapter {
	Class Holder() default RecyclerView.ViewHolder.class;
	int LayoutId() default -1;
	QAdapterManager.HolderId ID() default  QAdapterManager.HolderId.ONE;
}
