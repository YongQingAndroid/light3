package com.posun.view.ios;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;
import com.posun.unit.QlightUnit;
import com.posun.view.QDialog;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 作者：zyq on 2017/3/2 17:01
 * 不建议单例或者静态引用
 * 邮箱：zyq@posun.com
 */
public class IOSTimePickerUnite {
    private String deformat="yyyy-MM-dd hh:mm";
    private boolean issetAnim=false;
    public IOSTimePickerUnite set(TextView textView){
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show((TextView) view,deformat,Format.YMDHm);
            }
        });
        return this;
    }
    public IOSTimePickerUnite set(TextView textView,final String arg,final Format state){
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show((TextView) view,arg,state);
            }
        });
        return this;
    }
    public void setAnim(){
        issetAnim=true;
    }
    private void show(final TextView textView,String format,final Format state){
        if(QlightUnit.isEmpty(format)){
            format=deformat;
        }
        final SimpleDateFormat sf=new SimpleDateFormat(format);
        final QDialog qDialog=new QDialog(textView.getContext());
        if(issetAnim){
            qDialog.setAnim();
        }
        final IOSTimePickerLayout mIOSTimePickerLayout=new IOSTimePickerLayout(textView.getContext(),state.formats);
        mIOSTimePickerLayout.setThemeColor(Color.parseColor("#1E82FF"));
        String time=String.valueOf(textView.getText());
        if(!QlightUnit.isEmpty(time)){
            try {
                mIOSTimePickerLayout.setDate(sf.parse(time));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        qDialog.setContentView(mIOSTimePickerLayout.getView());
        mIOSTimePickerLayout.cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                qDialog.cancel();
            }
        });
        mIOSTimePickerLayout.sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText(sf.format(mIOSTimePickerLayout.getTime()));
                qDialog.cancel();
            }
        });
        qDialog.show();
    }
    public enum Format{
        YMDHm(new IOSTimePickerLayout.FormatState[]{IOSTimePickerLayout.FormatState.YYYY, IOSTimePickerLayout.FormatState.MM, IOSTimePickerLayout.FormatState.DD, IOSTimePickerLayout.FormatState.HH, IOSTimePickerLayout.FormatState.mm}),
        YMDH(new IOSTimePickerLayout.FormatState[]{IOSTimePickerLayout.FormatState.YYYY, IOSTimePickerLayout.FormatState.MM, IOSTimePickerLayout.FormatState.DD, IOSTimePickerLayout.FormatState.HH}),
        YMD(new IOSTimePickerLayout.FormatState[]{IOSTimePickerLayout.FormatState.YYYY, IOSTimePickerLayout.FormatState.MM, IOSTimePickerLayout.FormatState.DD}),
        YM(new IOSTimePickerLayout.FormatState[]{IOSTimePickerLayout.FormatState.YYYY, IOSTimePickerLayout.FormatState.MM}),
        MD(new IOSTimePickerLayout.FormatState[]{IOSTimePickerLayout.FormatState.MM, IOSTimePickerLayout.FormatState.DD}),
        Hm (new IOSTimePickerLayout.FormatState[]{IOSTimePickerLayout.FormatState.HH, IOSTimePickerLayout.FormatState.mm});
        private IOSTimePickerLayout.FormatState[] formats;
        Format(IOSTimePickerLayout.FormatState[] formats){
           this.formats=formats;
        }
    }
}
