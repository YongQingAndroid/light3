package com.posun.mvpframework.model;

/**
 * Created by dell on 2017/1/17.
 */
public interface BaseModeInterface{
    void free();
}
