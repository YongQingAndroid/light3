package com.posun.view.ios;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.posun.unit.QlightUnit;
import com.posun.view.QDialog;
/**
 * package OKSALES_PDA:com.posun.view.ios.IOSBottomMeunDialog.class
 * 作者：zyq on 2017/3/3 16:20
 * 邮箱：zyq@posun.com
 */
public class IOSBottomMeunDialog extends QDialog{
    private LinearLayout IOSGroup;
    private RadioGroup defultContenView;
    private ScrollView mScrollView;
    private int itemheight=45;
    private int mColor=Color.parseColor("#1E82FF");
    private LinearLayout.LayoutParams layoutParams;
    private boolean isline=false;
    public IOSBottomMeunDialog(Context context) {
        super(context);
        layoutParams=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, QlightUnit.dip2px(context,45));
        initIOSBottomMeun();
    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void initIOSBottomMeun() {
        itemheight=QlightUnit.dip2px(getContext(),45);
        IOSGroup=new LinearLayout(getContext());
        IOSGroup.setOrientation(LinearLayout.VERTICAL);
        mScrollView=new ScrollView(getContext());
        mScrollView.setBackground(new IOSDrawable());
        defultContenView=new RadioGroup(getContext());
        defultContenView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        defultContenView.setOrientation(LinearLayout.VERTICAL);
        defultContenView.setGravity(Gravity.CENTER);
        mScrollView.addView(defultContenView);
        TextView textView=new TextView(getContext());
        textView.setText("取消");
        textView.setTextColor(mColor);
        textView.setGravity(Gravity.CENTER);
        textView.setBackground(new IOSDrawable());
        LinearLayout.LayoutParams lp= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,itemheight);
        lp.setMargins(20,0,20,20);
        IOSGroup.addView(mScrollView);
        IOSGroup.addView(textView,lp);
        setlistener();
        super.setContentView(IOSGroup);
    }

    @Override
    public void setContentView(int layoutResID) {
    }

    @Override
    public void setContentView(View view) {
    }

    private void setlistener(){
        IOSGroup.getChildAt(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IOSBottomMeunDialog.this.cancel();
            }
        });
        defultContenView.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                Toast.makeText(getContext(), ""+radioGroup.findViewById(i).getTag(), Toast.LENGTH_SHORT).show();
                IOSBottomMeunDialog.this.cancel();
            }
        });
    }
    public void setData(String [] meuns){
        LinearLayout.LayoutParams rootlp;
        int ScreenHeight=QlightUnit.getDisplay(getContext()).heightPixels;
        int size=meuns.length;
        if((size*itemheight)<(ScreenHeight/1.8)){
            rootlp =new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
        }else{
            rootlp =new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,(int)(ScreenHeight/1.8));
        }
        rootlp.setMargins(20,0,20,20);
        mScrollView.setLayoutParams(rootlp);
        ViewGroup.LayoutParams lp=new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,1);

        for(int i=0;i<size;i++){
            RadioButton radioButton=new RadioButton(getContext());
            radioButton.setGravity(Gravity.CENTER);
            radioButton.setTextColor(mColor);
            radioButton.setText(meuns[i]);
            radioButton.setTag(i);
            radioButton.setButtonDrawable(android.R.color.transparent);
            addView(radioButton);
            if(isline&&i<size-1){
                View line=new View(getContext());
                line.setBackgroundColor(Color.GRAY);
                defultContenView.addView(line,lp);
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void show() {
        super.show();
    }

    public void addView(View view){
        defultContenView.addView(view,layoutParams);
        isline=true;
   }
}
