package com.posun.reflect;

/**
 * 反射对象管理类
 * code is far away from bug with the animal protecting
 *  ┏┓　　　┏┓
 *┏┛┻━━━┛┻┓
 *┃　　　　　　　┃ 　
 *┃　　　━　　　┃
 *┃　┳┛　┗┳　┃
 *┃　　　　　　　┃
 *┃　　　┻　　　┃
 *┃　　　　　　　┃
 *┗━┓　　　┏━┛
 *　　┃　　　┃神兽保佑
 *　　┃　　　┃代码无BUG！
 *　　┃　　　┗━━━┓
 *　　┃　　　　　　　┣┓
 *　　┃　　　　　　　┏┛
 *　　┗┓┓┏━┳┓┏┛
 *　　　┃┫┫　┃┫┫
 *　　　┗┻┛　┗┻┛
 *  用于已知的android隐藏类或者隐藏接口函数的使用
 *  仅仅适用于可以直接强引用的对象
 *  隐藏的类的构造方法务必确定当前构造方法类的正确性
 */
public class QreflexManager {
 public static ReflexObject getreflexObject(String name, Class[] classes, Object[] objects) throws Exception{
     return new ReflexObject(Class.forName(name),classes,objects);
 }
}
