package com.resources.bean;
import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONReader;
import com.posun.lighthttplibrary.R;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

/**
 * 作者：zyq on 2017/3/7 10:41
 * 邮箱：zyq@posun.com
 */
public class DataString {
    private  <T> List<T> praseData(Class<T> clazz,  Context context){
        try {
            InputStream stream= context.getResources().openRawResource(R.raw.data);
            InputStreamReader isr = new InputStreamReader(stream);
           return JSON.parseArray(new JSONReader(isr).readString(),clazz);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public <T> List<T> getJSonData(Class<T> clazz, Context context){
       return praseData(clazz,context);
    }
}
