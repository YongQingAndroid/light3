package com.posun.Excutor.Rxbus;
import android.view.View;
import java.util.Enumeration;
import java.util.Hashtable;
/**
 * 线程安全的点击事件处理类
 * 增加自动事件过滤事件分发
 * 注意：不建议使用单例模式单例模式下需要在actvity中手动释放，否则会引起内存泄露，造成对象无法被GC回收（free）
 * Created by zyq on 2017/1/22.
 */
public class ClickBus implements View.OnClickListener{
    private Hashtable<Integer,ClickBusEnity> map=new Hashtable<>();
    private ClickBusEnity clickbusenity_catch;
    /**
     * 绑定View视图view监听器
     * */
    public ClickBus bind_click(View view){
        clickbusenity_catch=new ClickBusEnity();
        clickbusenity_catch.view=view;
        return this;
    }
    /**
     * 事件回调触发器
     * */
    public void execut(ClickBusback clickBusback){
        clickbusenity_catch.view.setOnClickListener(this);
        clickbusenity_catch.clickBusback=clickBusback;
        map.put(clickbusenity_catch.view.getId(),clickbusenity_catch);
        clickbusenity_catch=null;
    }
    /**
     * 过滤连续点击的时间间隔
     * */
    public ClickBus filter_time(long time){
        clickbusenity_catch.time=time;
        clickbusenity_catch.istimefilter=true;
        return this;
    }
    /**
     * 处理点击事件
     * */
    @Override
    public void onClick(View view) {
        ClickBusEnity clickBusEnity=map.get(view.getId());
        if(clickBusEnity.istimefilter){
            if(clickBusEnity.start==0){
                clickBusEnity.start=System.currentTimeMillis();
                clickBusEnity.clickBusback.click(view);
            }else if(System.currentTimeMillis()-clickBusEnity.start>clickBusEnity.time){
                clickBusEnity.clickBusback.click(view);
                clickBusEnity.start=System.currentTimeMillis();
            }
        }else{
            clickBusEnity.clickBusback.click(view);
        }

    }
    public interface ClickBusback{
    void click(View view);
    }
    private class ClickBusEnity{
        protected View view;
        protected ClickBusback clickBusback;
        protected boolean istimefilter=false;
        protected long time=1000,start=0;
    }
    /**
     * 释放所有绑定的视图释放内存空间，建议在finish 方法里面使用(注意非单例模式下不用调用释放)
     * */
    public void free(){
        Enumeration e = map.keys();
        while( e. hasMoreElements() ){
            map.get(e.nextElement()).view.setOnClickListener(null);
        }
        map.clear();
    }
    /**
     * 解除单个帮个view事件
     * */
    public void unregisterClick(View view){
        if(!map.containsKey(view.getId()))
            return;
        map.get(view.getId()).view.setOnClickListener(null);
        map.remove(view.getId());
    }
    /**
     * 解除单个帮个view事件
     * */
    public void unregisterClick(int  view_id){
        if(!map.containsKey(view_id))
            return;
        map.get(view_id).view.setOnClickListener(null);
        map.remove(view_id);
    }
}
