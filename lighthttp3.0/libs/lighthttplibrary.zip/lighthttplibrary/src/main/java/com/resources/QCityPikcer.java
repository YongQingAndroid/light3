package com.resources;
import android.content.Context;
import com.posun.view.QDialog;

/**
 * package OKSALES_PDA:com.resources.QCityPikcer.class
 * 作者：zyq on 2017/3/7 16:45
 * 邮箱：zyq@posun.com
 */
public class QCityPikcer {
    private CityPIcker picker;
    private QDialog daiglog;
    public void setCityPicker(Context context){
        if(picker==null){
            picker=new CityPIcker(context, CityPIcker.State.PROVINCE, CityPIcker.State.CITY, CityPIcker.State.AREA);
            daiglog=new QDialog(context);
            daiglog.setContentView(picker);
            daiglog.setAnim();
            daiglog.setGravity(QDialog.QGriavty.BOTTOM);
        }
        daiglog.show();
    }
}
