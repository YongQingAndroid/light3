package com.posun.mvpframework.presenter;
import com.posun.lighthttplibrary.annotation.LightMvpAsyn;
import com.posun.lighthttplibrary.callback.QlightCallBack;
import com.posun.mvpframework.view.BaseViewInterface;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

public class PraseModleHandler implements InvocationHandler{
    private Object object;
    private BaseViewInterface baseViewInterface;
        public PraseModleHandler(Object object,BaseViewInterface baseViewInterface) {
            super();
            this.baseViewInterface=baseViewInterface;
            this.object=object;
        }
        public Object invoke(Object proxy, Method method, Object[] args){
              Type type= method.getGenericReturnType();
              try{
                  if (type.equals(void.class)){
                      method.invoke(object,praseMethond(method,args));
                  }else{
                      return  method.invoke(object,args);
                  }
              }catch (Throwable e){
                  baseViewInterface.faile(e.getCause());
              }
              return null;
        }
       private Object[] praseMethond(final Method method, Object[] args){
           Annotation[][] parameterAnnotations = method.getParameterAnnotations();
           if(parameterAnnotations==null||parameterAnnotations.length<1){
               return args;
           }
           int size=parameterAnnotations.length;
           for(int i=0;i<size;i++){
               Annotation mAnnotation= parameterAnnotations[i][0];
               if(mAnnotation!=null&&mAnnotation instanceof LightMvpAsyn){
                   args[i]=new QlightCallBack() {
                       @Override
                       public void execute(Object object) {
                           baseViewInterface.sucess(object,method.getName());
                       }
                   };
                   break;
               }
           }
           return args;
       }

    }