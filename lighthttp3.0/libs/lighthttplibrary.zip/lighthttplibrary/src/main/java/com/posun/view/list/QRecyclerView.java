package com.posun.view.list;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.posun.view.list.adapter.BaseRecyAdapter;
import com.posun.view.list.listener.RecyclerTouchListener;
import com.posun.view.list.suspension.ISuspensionInterface;
import com.posun.view.list.suspension.SuspensionDecoration;
import com.posun.view.list.swipmeun.SwipMenuAdapter;

import java.util.List;

/**
 * ┌───┐   ┌───┬───┬───┬───┐ ┌───┬───┬───┬───┐ ┌───┬───┬───┬───┐
 * │Esc│   │ F1│ F2│ F3│ F4│ │ F5│ F6│ F7│ F8│ │ F9│F10│F11│F12│ │P/S│S L│P/B│  ┌┐    ┌┐    ┌┐
 * └───┘   └───┴───┴───┴───┘ └───┴───┴───┴───┘ └───┴───┴───┴───┘
 * ┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───────┐
 * │~ `│! 1│@ 2│# 3│$ 4│% 5│^ 6│& 7│* 8│( 9│) 0│_ -│+ =│ BacSp │ │Ins│Hom│PUp│ │N L│ / │ * │ - │
 * ├───┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─────┤
 * │ Tab │ Q │ W │ E │ R │ T │ Y │ U │ I │ O │ P │{ [│} ]│ | \ │ │Del│End│PDn│ │ 7 │ 8 │ 9 │   │
 * ├─────┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴─────┤
 * │ Caps │ A │ S │ D │ F │ G │ H │ J │ K │ L │: ;│" '│ Enter  │               │ 4 │ 5 │ 6 │   │
 * ├──────┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴────────┤
 * │ Shift  │ Z │ X │ C │ V │ B │ N │ M │< ,│> .│? /│  Shift   │     │ ↑ │     │ 1 │ 2 │ 3 │   │
 * ├─────┬──┴─┬─┴──┬┴───┴───┴───┴───┴───┴──┬┴───┼───┴┬────┬────┤
 * │ Ctrl│    │Alt │         Space         │ Alt│    │    │Ctrl│ │ ← │ ↓ │ → │ │   0   │ . │←─┘│
 * └─────┴────┴────┴───────────────────────┴────┴────┴────┴────┘
 * power by ZYQ
 * 自定義RecyclerView 实现下拉刷新，和加载更多
 */
public class QRecyclerView extends RecyclerView {
    private View view;
    private float mLastY = -1;
    private int truetotalCount = 0;
    private boolean isHeader = false, isFooter = false, isRefreshHeader = false, isLoadMore = false,showProgress=false;
    private RecyclerTouchListener  SwipMenuTouchListener;
    private SimpleAdapter simpleAdapter;
    private FootView footview;
    private DragFace pull_layout;
    private boolean isStaggeredGridLayoutManager = false,isTop=false;
    private GridLayoutManager gridManager;
    private QRecyclerViewInterface callback;
    private SuspensionDecoration titalLable;
    private static final float DRAG_RATE = 3; /**** 拖动阻尼**/
    private final AdapterDataObserver mDataObserver = new DataObserver();
    public QRecyclerView(Context context) {
        super(context);
    }
    public QRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public void setRefresh(boolean isRefreshHeader) {
        setRefresh(isRefreshHeader,PraseDragView.class);
    }
    public void setRefresh(boolean isRefreshHeader,Class<? extends DragContentView> clazz) {
        this.isRefreshHeader = isRefreshHeader;
        this.showProgress=true;
        pull_layout = new DragFace(getContext(),clazz);
    }
    public void setLoadMore(boolean isLoadMore) {
        this.isLoadMore = isLoadMore;
        footview = new FootView(getContext());
    }

    @Override
    public void setAdapter(Adapter adapter) {
        simpleAdapter = new SimpleAdapter(adapter);
        adapter.registerAdapterDataObserver(mDataObserver);
        RsetLayoutManager();
        super.setAdapter(simpleAdapter);
        if(adapter instanceof BaseRecyAdapter){
            BaseRecyAdapter baseRecyAdapter= (BaseRecyAdapter) adapter;
            if(baseRecyAdapter.getSwipmenuAdapter()!=null){
                this.addOnItemTouchListener(baseRecyAdapter.getSwipmenuAdapter().getOnTouchListener());
            }
        }
    }
    /**
     * 对列表升序/降序分类
     * */
    public void setAutoTitle(List<? extends ISuspensionInterface> list){
          if(titalLable==null){
              titalLable=new SuspensionDecoration(getContext(),list);
              if(isRefreshHeader){
                  titalLable.setHeaderViewCount(1);
              }
              this.addItemDecoration(titalLable);
              return;
          }
        titalLable.setmDatas(list);
    }
    public void setCallback(QRecyclerViewInterface callback) {
        this.callback = callback;
    }

    @Override
    public Adapter getAdapter() {
        Adapter adapter = super.getAdapter();
        if (adapter instanceof SimpleAdapter) {
            return simpleAdapter.getAdapter();
        }
        return null;
    }

    @Override
    public void setLayoutManager(LayoutManager layout) {
        super.setLayoutManager(layout);
        if (layout instanceof GridLayoutManager) {
            gridManager = (GridLayoutManager) layout;
        } else if (layout instanceof StaggeredGridLayoutManager) {
            isStaggeredGridLayoutManager = true;
        }
    }

    private void RsetLayoutManager() {
        if (gridManager == null) {
            return;
        }
        gridManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return (simpleAdapter.isHeader(position) || simpleAdapter.isFooter(position) || simpleAdapter.isRefreshHeader(position))
                        ? gridManager.getSpanCount() : 1;
            }
        });
    }

    private boolean isOnTop() {
        return this.computeVerticalScrollOffset()==0;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (!isRefreshHeader) {
            return super.onInterceptTouchEvent(ev);
        }
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mLastY = ev.getRawY();
                if(SwipMenuTouchListener!=null){
                    SwipMenuTouchListener.setRefresh(false);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                isTop=isOnTop();
                break;
        }
        return super.onInterceptTouchEvent(ev);
    }
    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!isRefreshHeader) {
            return super.onTouchEvent(ev);
        }
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                    if(SwipMenuTouchListener!=null){
                        isTop=isOnTop();
                    }
                if (isTop&&pull_layout.state != DragState.LOADING) {
                    float deltaY = ev.getRawY() - mLastY;
                    if(deltaY>0){
                        pull_layout.onMove(deltaY / DRAG_RATE);
                        return true;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                if(pull_layout.state == DragState.LOADING){
                    pull_layout.continueAnimation();
                }else{
                    if(SwipMenuTouchListener!=null&&pull_layout.state != DragState.NORMAL){
                        SwipMenuTouchListener.setRefresh(true);
                    }
                    pull_layout.recovery();
                    if (pull_layout.state == DragState.LOADING && callback != null) {
                        callback.onRefresh();
                    }
                }
                break;
        }
        return super.onTouchEvent(ev);
    }

    @Override
    public void addOnItemTouchListener(OnItemTouchListener listener) {
        super.addOnItemTouchListener(listener);
        if(listener instanceof RecyclerTouchListener){
            SwipMenuTouchListener=(RecyclerTouchListener)listener;
        }
    }

    @Override
    public void onScrollStateChanged(int state) {
        super.onScrollStateChanged(state);
        if (!isLoadMore)
            return;
        if ( footview.state!= FootView.Loader.NOMORE&&state == RecyclerView.SCROLL_STATE_IDLE &&isSlideToBottom()) {
            switch ( footview.state){
                case NORMAL:
                    footview.state = FootView.Loader.LOADING;
                    isFooter = true;
                    simpleAdapter.adapter.notifyItemInserted(truetotalCount+1);
                    QRecyclerView.this.smoothScrollToPosition(truetotalCount);
                    if (callback != null) {
                        callback.LoadingMore();
                    }
                    break;
            }

        }
    }


    protected boolean isSlideToBottom() {
        if (this.computeVerticalScrollExtent() + this.computeVerticalScrollOffset() >= this.computeVerticalScrollRange())
            return true;
        return false;
    }
    public void changeLoadingMoreState(FootView.Loader state){
        footview.state=state;
        footview.PraseState();
        if(footview.state== FootView.Loader.NOMORE){
            isFooter = true;
            simpleAdapter.adapter.notifyItemChanged(truetotalCount);
        }
    }
    public void isLoadMore(boolean arg) {
        footview.state = FootView.Loader.NORMAL;
        if (isFooter && !arg) {
            isFooter = arg;
            simpleAdapter.adapter.notifyDataSetChanged();
        }
    }
    /**
     * 不使用下拉刷新但是使用刷新动画
     * **/
    public void hasProgress(boolean arg){
        if(arg){
            showProgress=true;
            pull_layout= new DragFace(getContext(),PraseDragView.class);
        }
    }
    public void isRefresh(boolean arg) {
        if (arg) {
            pull_layout.state = DragState.LOADING;
        } else {
            pull_layout.state = DragState.FINISH;
        }
        pull_layout.praseDragFaceState();
    }

    public void addHeardView(View view) {
        this.view = view;
        isHeader = true;
    }

    private class SimpleAdapter extends Adapter {
        private Adapter adapter;
        private int totalCount = 0;
        private final int HEARD = -100, TOP = -200, FOOT = -300;

        public SimpleAdapter(Adapter adapter) {
            this.adapter = adapter;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == HEARD && view != null) {
                if (isStaggeredGridLayoutManager) {
                    StaggeredGridLayoutManager.LayoutParams params = new StaggeredGridLayoutManager.LayoutParams(
                            StaggeredGridLayoutManager.LayoutParams.MATCH_PARENT, StaggeredGridLayoutManager.LayoutParams.WRAP_CONTENT);
                    params.setFullSpan(true);
                    view.setLayoutParams(params);
                }
                return new SimpleHolder(view);
            } else if (viewType == TOP) {
                if (isStaggeredGridLayoutManager) {
                    StaggeredGridLayoutManager.LayoutParams params = new StaggeredGridLayoutManager.LayoutParams(
                            StaggeredGridLayoutManager.LayoutParams.MATCH_PARENT, StaggeredGridLayoutManager.LayoutParams.WRAP_CONTENT);
                    params.setFullSpan(true);
                    pull_layout.setLayoutParams(params);
                }
                return new SimpleHolder(pull_layout);
            } else if (viewType == FOOT) {
                return new SimpleHolder(footview);
            }
            return adapter.onCreateViewHolder(parent, viewType);
        }

        public Adapter getAdapter() {
            return adapter;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if (showProgress)
                position--;
            if (isHeader)
                position--;
            if (position < 0) {
                return;
            }
            if (position == totalCount) {
                return;
            }
            adapter.onBindViewHolder(holder, position);
        }

        @Override
        public int getItemViewType(int position) {
            if (position == 0 && showProgress) {
                return TOP;
            } else if (position == 0 && isHeader) {
                return HEARD;
            } else if (position == 1 && isHeader && showProgress) {
                return HEARD;
            }
            if (showProgress)
                position--;
            if (isHeader)
                position--;
            if (position == totalCount) {
                return FOOT;
            }
            return adapter.getItemViewType(position);
        }

        @Override
        public int getItemCount() {
            int size = adapter.getItemCount();
            totalCount = size;
            if (showProgress)
                size++;
            if (isHeader)
                size++;
            if (isFooter)
                size++;
            truetotalCount = size;
            return size;
        }

        public boolean isHeader(int position) {
            if (showProgress) {
                return position == 1 && isHeader;
            } else {
                return position == 0 && isHeader;
            }
        }

        public boolean isFooter(int position) {
            if (isLoadMore) {
                return position == truetotalCount - 1&&isFooter;
            } else {
                return false;
            }
        }

        public boolean isRefreshHeader(int position) {
            return position == 0 && showProgress;
        }
        @Override
        public void onViewDetachedFromWindow(ViewHolder holder) {
            adapter.onViewDetachedFromWindow(holder);
        }

        @Override
        public void onViewRecycled(ViewHolder holder) {
            adapter.onViewRecycled(holder);
        }

        @Override
        public boolean onFailedToRecycleView(ViewHolder holder) {
            return adapter.onFailedToRecycleView(holder);
        }

        @Override
        public void unregisterAdapterDataObserver(AdapterDataObserver observer) {
            adapter.unregisterAdapterDataObserver(observer);
        }

        @Override
        public void registerAdapterDataObserver(AdapterDataObserver observer) {
            adapter.registerAdapterDataObserver(observer);
        }
    }

    private class SimpleHolder extends ViewHolder {
        public SimpleHolder(View itemView) {
            super(itemView);
        }
    }

    public interface QRecyclerViewInterface {
        void onRefresh();

        void LoadingMore();
    }
    /******************动态刷新数据********************************/
    private class DataObserver extends AdapterDataObserver {
        @Override
        public void onChanged() {
            if (simpleAdapter != null) {
                simpleAdapter.notifyDataSetChanged();
            }
        }
        @Override
        public void onItemRangeInserted(int positionStart, int itemCount) {
            simpleAdapter.notifyItemRangeInserted(positionStart, itemCount);
        }
        @Override
        public void onItemRangeChanged(int positionStart, int itemCount) {
            simpleAdapter.notifyItemRangeChanged(positionStart, itemCount);
        }
        @Override
        public void onItemRangeChanged(int positionStart, int itemCount, Object payload) {
            simpleAdapter.notifyItemRangeChanged(positionStart, itemCount, payload);
        }

        @Override
        public void onItemRangeRemoved(int positionStart, int itemCount) {
            simpleAdapter.notifyItemRangeRemoved(positionStart, itemCount);
        }

        @Override
        public void onItemRangeMoved(int fromPosition, int toPosition, int itemCount) {
            simpleAdapter.notifyItemMoved(fromPosition, toPosition);
        }
    };
    public enum DragState {
        NORMAL,
        DRAGE,
        DRAGE_DOWN,
        LOADING,
        LOADINGCONTINUE,
        FINISH
    }
}
