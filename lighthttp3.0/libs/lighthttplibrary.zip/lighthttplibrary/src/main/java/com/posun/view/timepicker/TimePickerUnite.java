package com.posun.view.timepicker;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;
import com.posun.unit.QlightUnit;
import com.posun.view.QDialog;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * package OKSALES_PDA:com.posun.view.timepicker.TimePickerUnite.class
 * 作者：zyq on 2017/3/2 17:01
 * 邮箱：zyq@posun.com
 */
public class TimePickerUnite {
    private String deformat="yyyy-MM-dd hh:mm";
    public void set(TextView textView){
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show((TextView) view,deformat,Format.YMDHm);
            }
        });
    }
    public void set(TextView textView,final Format state){
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show((TextView) view,deformat,state);
            }
        });
    }
    public void set(TextView textView,final String arg,final Format state){
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show((TextView) view,arg,state);
            }
        });
    }

    private void show(final TextView textView,String format,final Format state){
        final SimpleDateFormat sf=new SimpleDateFormat(format);
        final QDialog  qDialog=new QDialog(textView.getContext());
        final TimePickerLayout  mTimePickerLayout=new TimePickerLayout(textView.getContext(),state.formats);
        mTimePickerLayout.setThemeColor(Color.BLUE);
        String time=String.valueOf(textView.getText());
        if(!QlightUnit.isEmpty(time)){
            try {
                mTimePickerLayout.setDate(sf.parse(time));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        qDialog.setContentView(mTimePickerLayout.getView());
        mTimePickerLayout.cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                qDialog.cancel();
            }
        });
        mTimePickerLayout.sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText(sf.format(mTimePickerLayout.getTime()));
                qDialog.cancel();
            }
        });
        qDialog.show();
    }
    public enum Format{
        YMDHm(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.YYYY, TimePickerLayout.FormatState.MM, TimePickerLayout.FormatState.DD, TimePickerLayout.FormatState.HH, TimePickerLayout.FormatState.mm}),
        YMDH(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.YYYY, TimePickerLayout.FormatState.MM, TimePickerLayout.FormatState.DD, TimePickerLayout.FormatState.HH}),
        TMD(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.YYYY, TimePickerLayout.FormatState.MM, TimePickerLayout.FormatState.DD}),
        YM(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.YYYY, TimePickerLayout.FormatState.MM}),
        Y(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.YYYY}),
        M(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.MM}),
        MD(new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.MM, TimePickerLayout.FormatState.DD}),
        Hm (new TimePickerLayout.FormatState[]{TimePickerLayout.FormatState.HH, TimePickerLayout.FormatState.mm});
        private TimePickerLayout.FormatState[] formats;
        Format(TimePickerLayout.FormatState[] formats){
           this.formats=formats;
        }
    }
}
