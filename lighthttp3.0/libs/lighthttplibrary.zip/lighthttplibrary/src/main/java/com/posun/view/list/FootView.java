package com.posun.view.list;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.posun.unit.QlightUnit;

/**
 * Created by dell on 2017/1/16.
 */
public class FootView extends LinearLayout{
    public Loader state= Loader.NORMAL;
    private   TextView t;
    private    ProgressBar pross;
    public FootView(Context context) {
        super(context);
        init();
    }
    private void init() {
        LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(0, 0, 0, 0);
        this.setLayoutParams(layoutParams);
        this.setPadding(0, 0, 0, 0);
        this.setOrientation(HORIZONTAL);
        this.setGravity(Gravity.CENTER);
        int hight = QlightUnit.dip2px(getContext(), 20f);
        pross=new ProgressBar(getContext());
        LayoutParams lp=new LayoutParams(hight,hight);
        pross.setLayoutParams(lp);
        this.addView(pross);
        t=new TextView(getContext());
        t.setTextColor(Color.GRAY);
        t.setText("正在加载...");
        this.addView(t);
    }
    public void PraseState(){
        switch (state){
            case NOMORE:
                t.setText("没有更多数据了");
                pross.setVisibility(GONE);
                break;
            default:
                t.setText("正在加载...");
                pross.setVisibility(VISIBLE);
                break;
        }
    }
    public enum Loader{
        NORMAL,
        LOADING,
        FINSH,
        NOMORE
    }
}
