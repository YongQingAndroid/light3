package com.posun.lighthttplibrary.ResultCover;
import android.util.Log;

import com.posun.lighthttplibrary.QLightHttp;
import com.posun.unit.QlightUnit;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Type;

import okhttp3.Headers;
import okhttp3.Response;

/**
 * This network framework is based on the production of okhttp
 * Network framework free open source, and the final right to interpret the author.
 * The author will go regularly to update the business code, but no obligation to notify the user.
 * My open source community account is fengling136
 * Welcome attention
 * Thanks for your use
 * the power by ZYQ
 */
public class BaseStreamResultCover implements QLightHttp.LightHttpCover {
    protected static String defult_file = "/sdcard/";
    @Override
    public Object just(Response mObject, Type type,Object expandValue)throws Exception{
        InputStream inputStream = mObject.body().byteStream();
        File inputfile=new File(defult_file + QlightUnit.getUrlFileName(mObject.request().url().toString()));
        FileOutputStream fileOutputStream = new FileOutputStream(inputfile);
        byte[] buffer = new byte[1024*3];
        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            fileOutputStream.write(buffer, 0, len);
        }
        fileOutputStream.flush();
        Log.d(QLightHttp.TAG, "文件下载成功...");
        return inputfile.toString();
    }
    public static BaseStreamResultCover creat(String ...file) {
        if(file!=null&&file.length==1){
            return new BaseStreamResultCover(file[0]);
        }
        return new BaseStreamResultCover();
    }
    public BaseStreamResultCover(String file){
        this.defult_file=file;
    }
    public BaseStreamResultCover(){
    }
}
