package com.posun.unit;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 自定义服务
 * 长期存在的服务在清单文件中申明为单独进程
 * android:persistent="true"
 * setForeground(true);
 * android:process=”com.xxx.xxxservice”配置到单独的进程中）
 * package new_space:com.posun.unit.QService.class
 * 作者：zyq on 2017/3/10 09:23
 * 邮箱：zyq@posun.com
 */
public abstract class QService extends Service{
    /**是否开启小强模式（小强模式下建议注册BootReceiver到清单文Action 为com.lighthttp.qing.destroy）*/
    protected boolean forcedsurvival=false;
    private String mBroadcastReceiverflag="net.service.destroy";
    public QService(boolean forcedsurvival){
        this.forcedsurvival=forcedsurvival;
        initService();
    }
    protected void initService(){
//        if(forcedsurvival){
//            BootReceiver bootreceiver = new BootReceiver();//请在清单文件中注册BootReceiver保证服务存活
//            IntentFilter filter = new IntentFilter();
//            filter.addAction(mBroadcastReceiverflag);
//            registerReceiver(bootreceiver, filter);
//        }
    }
    @Override
    public void onDestroy() {
        if(forcedsurvival){
            stopForeground(true);
            Intent intent = new Intent(mBroadcastReceiverflag);
            sendBroadcast(intent);
        }
        super.onDestroy();
    }
    public class BootReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(mBroadcastReceiverflag)) {
                restartdService(context);
            }
        }
    }
     abstract Intent getIntent();
     protected void restartdService(Context context){
         context.startService(getIntent());
     }
}
