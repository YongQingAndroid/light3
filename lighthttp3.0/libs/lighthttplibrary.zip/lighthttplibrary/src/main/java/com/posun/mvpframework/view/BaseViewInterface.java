package com.posun.mvpframework.view;

/**
 * Created by dell on 2017/1/17.
 */
public interface BaseViewInterface {
    void sucess(Object o,String method);
    void faile(Throwable e);
}
