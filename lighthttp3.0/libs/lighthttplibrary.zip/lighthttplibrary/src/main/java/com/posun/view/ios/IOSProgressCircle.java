package com.posun.view.ios;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import com.posun.lighthttplibrary.R;

/**
 * 作者：zyq on 2017/3/10 15:38
 * 邮箱：zyq@posun.com
 */
public class IOSProgressCircle extends View {
    private Paint mPaint;
    private int mProgress = 0;
    private int mMax = 100;
    private int mBackgroundColor=Color.GRAY;
    private final int mCircleLineStrokeWidth = 20;
    public IOSProgressCircle(Context context, AttributeSet attrs) {
        super(context, attrs);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = this.getWidth();
        int height = this.getHeight();
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(mCircleLineStrokeWidth);
        mPaint.setColor(mBackgroundColor);
        RectF mRectF=new RectF();
        mRectF.left = mCircleLineStrokeWidth / 2; // 左上角x
        mRectF.top = mCircleLineStrokeWidth / 2; // 左上角y
        if(width>height){
            mRectF.right = height - mCircleLineStrokeWidth / 2; // 左下角x
            mRectF.bottom = height - mCircleLineStrokeWidth / 2; // 右下角y
        }else{
            mRectF.right = width - mCircleLineStrokeWidth / 2; // 左下角x
            mRectF.bottom = width - mCircleLineStrokeWidth / 2; // 右下角y
        }
        canvas.drawArc(mRectF, 180, 360, false, mPaint);
        mPaint.setStrokeWidth(mCircleLineStrokeWidth);
        mPaint.setColor(Color.BLUE);
//        mPaint.setStyle(Paint.Style.FILL);
        canvas.drawArc(mRectF, 180, (360*mProgress)/mMax, false, mPaint);
    }

    public void setprogress(int arg) {
            mProgress+=arg;
        if (mProgress > mMax)
            mProgress = 0;
            invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}
