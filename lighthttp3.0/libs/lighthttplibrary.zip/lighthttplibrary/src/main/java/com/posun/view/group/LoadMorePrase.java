package com.posun.view.group;
import android.animation.ValueAnimator;
import android.content.Context;
import android.support.design.widget.Snackbar;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.posun.unit.QlightUnit;

/**
 * Created by qing on 2017/2/25.
 */

public class LoadMorePrase extends LinearLayout{
    private View rootView;
    protected Load_state state=Load_state.NORMAL;
    private ViewGroup.LayoutParams top_lp;
    private LayoutParams layoutParams;
    private ProgressBar progressBar;
    private int Max_height=100;
    public LoadMorePrase(Context context) {
        super(context);
    }

    protected void init(View rootView){
        this.rootView=rootView;
        praseUI();
    }
    private void praseUI(){
        layoutParams=new LayoutParams(LayoutParams.MATCH_PARENT,0);
        this.setOrientation(HORIZONTAL);
        this.setLayoutParams(layoutParams);
        this.setGravity(Gravity.CENTER);
        progressBar=new ProgressBar(getContext());
        ViewGroup.LayoutParams layoutParams1=new ViewGroup.LayoutParams(QlightUnit.dip2px(getContext(),20),LayoutParams.WRAP_CONTENT);
        this.addView(progressBar,layoutParams1);
        TextView textView=new TextView(getContext());
        textView.setText("加载更多");
        this.addView(textView);

    }
    protected void resetHeight(){
        top_lp=rootView.getLayoutParams();
    }
    private void praseLp(int arg){
       if(top_lp==null){
           top_lp=rootView.getLayoutParams();
       }
        if(top_lp instanceof RelativeLayout.LayoutParams){
            RelativeLayout.LayoutParams lp=(RelativeLayout.LayoutParams)top_lp;
            lp.setMargins(0,arg,0,0);
            rootView.setLayoutParams(lp);
        }else if(top_lp instanceof LayoutParams){
            LayoutParams lp=(LayoutParams)top_lp;
            lp.setMargins(0,arg,0,0);
            rootView.setLayoutParams(lp);
        }else if(top_lp instanceof FrameLayout.LayoutParams){
            FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)top_lp;
            lp.setMargins(0,arg,0,0);
            rootView.setLayoutParams(lp);
        }
    }
    protected void move(float arg){
        if(Math.abs(arg)>Max_height){
            state=Load_state.LOADING;
        }else{
            state=Load_state.DRAGE;
        }
        layoutParams.height=(int)Math.abs(arg);
        praseLp((int)arg);
    }
    protected enum Load_state{
        NORMAL,
        DRAGE,
        LOADING,
        FINISH
    }
    protected void recovery(){
        if(state==Load_state.LOADING){
            smoothScrollTo(0);
            Snackbar.make(this,"加载更多",Snackbar.LENGTH_SHORT).show();
        }else{
            smoothScrollTo(0);
            state=Load_state.NORMAL;
        }
    }
    private void praseState(int arg){
        switch (state){
            case DRAGE:
                break;
            case LOADING:
                break;
        }
    }
    private void smoothScrollTo(int destHeight) {
        ValueAnimator animator = ValueAnimator.ofInt(layoutParams.height, destHeight);
        animator.setDuration(200).start();
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                setVisibleHeight((int) animation.getAnimatedValue());
            }
        });
        animator.start();
    }
    private void setVisibleHeight(int arg){
        praseLp(0-Math.abs(arg));
    }
}
