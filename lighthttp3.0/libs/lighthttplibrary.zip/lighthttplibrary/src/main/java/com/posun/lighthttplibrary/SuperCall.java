package com.posun.lighthttplibrary;

/**
 * Created by dell on 2016/10/25.
 */
public interface SuperCall{
}
