package com.posun.lighthttplibrary.callback;

/**
 * Created by dell on 2017/1/9.
 */
public interface QlightCallBack {
    void execute(Object object);
}
