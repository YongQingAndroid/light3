package com.posun.lighthttplibrary.lightHttp;

import com.posun.lighthttplibrary.LightHttpRequest;
import com.posun.lighthttplibrary.SuperCall;
import java.io.IOException;
import java.lang.reflect.Type;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;
/**
 * This network framework is based on the production of okhttp
 * Network framework free open source, and the final right to interpret the author.
 * The author will go regularly to update the business code, but no obligation to notify the user.
 * My open source community account is fengling136
 * Welcome attention
 * Thanks for your use
 * the power by ZYQ
 */
public class QLightCall<T> implements SuperCall {
    private Type type;
    private LightHttpRequest mRequest;
    public QLightCall(Type type, LightHttpRequest mRequest){
        this.mRequest=mRequest;
        this.type=type;
    }
    public Call call(final QCall<QLightResponseEntity<T>> value) {
        Call call = new OkHttpClient().newCall(mRequest.getRequest());
        if (Thread.currentThread().getName().equalsIgnoreCase("main")) {
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    value.onFaile(e);
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    try {
                        T result=(T)mRequest.getCover().just(response,type,mRequest.getSoapElement());
                        value.onSuccess(new QLightResponseEntity<T>(result,mRequest.getRequest().method()));
                    } catch (Exception e) {
                        value.onFaile(e);
                    }
                }
            });
        }else{
            try {
                Response response= call.execute();
                T result=(T)mRequest.getCover().just(response,type,mRequest.getSoapElement());
                value.onSuccess(new QLightResponseEntity<T>(result,mRequest.getRequest().method()));
            } catch (Exception e) {
                value.onFaile(e);
            }
        }
        return call;
    }
}
