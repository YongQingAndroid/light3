package com.posun.view.chart;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * 作者：zyq on 2017/6/19 8:38
 * 邮箱：zyq@posun.com
 */
public class BinView extends View {
    private Paint mPaint;
    private List<BinData> list=new ArrayList<>();
    private long mMax = 100;
    private int Animation=0;
    private  int mCircleLineStrokeWidth = 80;
    public BinView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
    }

    public void setCircleLineStrokeWidth(int mCircleLineStrokeWidth) {
        this.mCircleLineStrokeWidth = mCircleLineStrokeWidth;
    }
    public void Reset() {
        list.clear();
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = this.getWidth();
        int height = this.getHeight();
        mPaint.setStyle(Paint.Style.STROKE);
        RectF mRectF=new RectF();
        mRectF.left = mCircleLineStrokeWidth / 2; // 左上角x
        mRectF.top = mCircleLineStrokeWidth / 2; // 左上角y
        if(width>height){
            mRectF.right = height - mCircleLineStrokeWidth / 2; // 左下角x
            mRectF.bottom = height - mCircleLineStrokeWidth / 2; // 右下角y
        }else{
            mRectF.right = width - mCircleLineStrokeWidth / 2; // 左下角x
            mRectF.bottom = width - mCircleLineStrokeWidth / 2; // 右下角y
        }
        mPaint.setStrokeWidth(mCircleLineStrokeWidth);
        if(list.size()==0){
            mPaint.setColor(Color.GRAY);
            canvas.drawArc(mRectF, 180, 360, false, mPaint);
        }else{
            float start=-90;
            if(Animation!=0){
                for(BinData item:list){
                    mPaint.setColor(item.getColor());
                    float end=Math.round((360.0*item.getData())/mMax);
                    canvas.drawArc(mRectF, start,(end*Animation)/100, false, mPaint);
                    start+=end;
                }
            }else{
                for(BinData item:list){
                    mPaint.setColor(item.getColor());
                    float end=Math.round((360.0*item.getData())/mMax);
                    canvas.drawArc(mRectF, start,end , false, mPaint);
                    start+=end;
                }
            }
        }
    }


    public BinView setData(BinData arg){
        list.add(arg);
        return this;
    }
    public void commit(){
        Animation=0;
        long total=0;
        for(BinData item:list){
            total+=item.getData();
        }
        mMax=  total;
        invalidate();
    }
    public void commitwhitAnimation(){
        long total=0;
        for(BinData item:list){
            total+=item.getData();
        }
        mMax=  total;
        new Thread(new Runnable() {
            @Override
            public void run() {
                Animation=0;
                postInvalidate();
                while (Animation<100){
                    Animation+=5;
                    postInvalidate();
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public static class   BinData{
        private long data;
        private int color;
        public BinData(long data,int color){
            this.data=data;
            this.color=color;
        }

        public long getData() {
            return data;
        }

        public void setData(long data) {
            this.data = data;
        }

        public int getColor() {
            return color;
        }

        public void setColor(int color) {
            this.color = color;
        }
    }
}
