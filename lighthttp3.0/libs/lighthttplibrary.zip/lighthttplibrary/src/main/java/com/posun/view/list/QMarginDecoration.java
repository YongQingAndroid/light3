package com.posun.view.list;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.posun.unit.QlightUnit;

public class QMarginDecoration extends RecyclerView.ItemDecoration {
  private int margin;
  private Paint paint;
  public QMarginDecoration(Context context) {
    margin = QlightUnit.dip2px(context,3f);
  }

  public QMarginDecoration(Context context,float arg) {
    margin = QlightUnit.dip2px(context,arg);
  }
  @Override
  public void getItemOffsets(
      Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
     outRect.set(0, 0, 0, margin);

  }
}