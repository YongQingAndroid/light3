package com.posun.Excutor;
import com.posun.unit.QlightUnit;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
/**
 * 对象，以及域，生命周期管理（删除原有singletone管理类）
 * package OKSALES_PDA:com.posun.Excutor.ObjectInstnet.class
 * 作者：zyq on 2017/3/8 10:27
 * 邮箱：zyq@posun.com
 */
public class ObjectInstnet {
    private static ConcurrentMap<Object, ConcurrentMap<Class, Object>> map;
    /**
     * 绑定管理闭包域的生命周期
     * */
    public static void BindLifeCycle(Object object) {
        if (map == null) {
            map = new ConcurrentHashMap<>();
        }
        if(object!=null)synchronized(map){
            map.put(object,new ConcurrentHashMap<Class,Object>());
        }
    }
    /**
     * 获取对象
     * @param arg 对象所属的域
     * */
    public static <T> T getInstent(Class<T> type,Object... arg) {
        if (map == null) {
            map = new ConcurrentHashMap<>();
        }
        Object key;
        if(QlightUnit.isEmpty(arg)){
            key="default";
        }else{
            key=arg[0];
        }
        if(map.get(key)==null)synchronized(map){
            map.put(key,new ConcurrentHashMap<Class, Object>());
        }
         Object object=map.get(key).get(type);
        if(object==null)synchronized(map){
            try {
                object=type.newInstance();
                map.get(key).put(type,object);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return (T)object;
    }
    /**
     * 释放所在域的所有对象
     * */
    public static void freeLifeCycle(Object key){
          map.remove(key);
    }
    /**
     * 释放默认对象空间
     * */
    public static void removeObject(Object key){
        if(map==null||map.containsKey("default")){
          return;
        }
        map.get("default").remove(key);
    }
    /**
     *释放内存 重置管理
     * */
    public static void free(){
        map=null;
    }
    }
