package com.posun.view.ios;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.posun.lighthttplibrary.R;
import com.posun.unit.QlightUnit;
import com.posun.view.QDialog;
import com.posun.view.QToast;

/**
 * package OKSALES_PDA:com.posun.view.ios.IOSBottomMeunDialog.class
 * 作者：zyq on 2017/3/3 16:20
 * 邮箱：zyq@posun.com
 */
public class IOSTopMeunDialog extends QDialog{
    private ListView mListview;
    private int itemheight=45;
    private int mColor=Color.parseColor("#1E82FF");
    private View view;
    public IOSTopMeunDialog(View view) {
        super(view.getContext());
        this.view=view;
        initIOSBottomMeun();
    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void initIOSBottomMeun() {
        setFullSrceen(true);
        setGravity(QGriavty.TOP);
        itemheight=QlightUnit.dip2px(getContext(),45);
        mListview=new ListView(getContext());
        mListview.setDivider(new ColorDrawable(Color.GRAY));
        mListview.setDividerHeight(1);
        mListview.setBackgroundColor(Color.WHITE);
        setlistener();
        super.setContentView(mListview);
    }

    @Override
    public void setContentView(int layoutResID) {
    }

    @Override
    public void setContentView(View view) {
    }

    @Override
    public QDialog setAnim() {
        window.setWindowAnimations(R.style.androidanim);
        return this;
    }

    private void setlistener(){
        mListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                QToast.makeText(getContext(),i+"",QToast.LENGTH_SHORT).show();
                IOSTopMeunDialog.this.cancel();
            }
        });
    }
    public void setData(String [] meuns){
        FrameLayout.LayoutParams rootlp;
        rootlp =new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.WRAP_CONTENT);
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int y = location[1];
        rootlp.setMargins(0,y+(view.getHeight()/2),0,0);/**计算当前View的底部坐标**/
        mListview.setLayoutParams(rootlp);
        mListview.setAdapter(new MeunAdapter(meuns));
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void show() {
        super.show();
    }
    class MeunAdapter extends BaseAdapter{
        String[] items;
        private AbsListView.LayoutParams layoutParams=new AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT,itemheight);
        protected MeunAdapter( String[] items){
            this.items=items;
        }
        @Override
        public int getCount() {
            return items.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if(view==null){
                TextView textView= new TextView(viewGroup.getContext());
                textView.setGravity(Gravity.CENTER);
                textView.setTextColor(mColor);
                textView.setLayoutParams(layoutParams);
                view=textView;
            }
            ((TextView)view).setText(items[i]);
            return view;
        }
    }
}
