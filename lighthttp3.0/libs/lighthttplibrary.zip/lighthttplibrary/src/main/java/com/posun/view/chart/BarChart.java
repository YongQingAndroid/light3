package com.posun.view.chart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by zyq on 2017/2/23.
 */
public class BarChart extends View{
    private Paint paint;
    public BarChart(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint=new Paint();
    }
    public BarChart(Context context) {
        super(context);
        paint=new Paint();
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Rect rect1 = new Rect(100, 100,120, 600);
        LinearGradient lg = new LinearGradient(
                rect1.left, rect1.bottom, rect1.right, rect1.bottom,
               new int[]{Color.RED,Color.WHITE,Color.RED},new float[]{0,0.5f,1}, Shader.TileMode.CLAMP);
        paint.setShader(lg);
        canvas.drawRect(rect1, paint);
        canvas.translate(rect1.width() + 30,0);
        Rect rect3 = new Rect(rect1);
        paint.setShader(lg);
        canvas.drawRect(rect3, paint);
    }
}
