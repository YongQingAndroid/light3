package com.posun.lighthttplibrary.adapterCover;

import com.posun.lighthttplibrary.LightHttpRequest;
import com.posun.lighthttplibrary.QLightHttp;
import java.io.IOException;
import java.lang.reflect.Type;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import rx.Observable;
import rx.Subscriber;

/**
 * Created by zyq on 2016/10/25.
 */
public class QBaseRxAdapterCover implements QLightHttp.LightAdapterCover<Observable.OnSubscribe> {
    @Override
    public Observable.OnSubscribe adapter(final Type type, final LightHttpRequest mRequest) {
        return new Observable.OnSubscribe<Object>() {
            @Override
            public void call(final Subscriber<? super Object> subscriber) {
                Call call = new OkHttpClient().newCall(mRequest.getRequest());
                if (Thread.currentThread().getName().equalsIgnoreCase("main")) {
                    /***当前线程为主线程**/
                    call.enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            subscriber.onError(e);
                        }
                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            try {
                                subscriber.onNext(mRequest.getCover().just(response, type, mRequest.getSoapElement()));
                            } catch (Throwable e) {
                                subscriber.onError(e);
                            } finally {
                                subscriber.onCompleted();
                            }
                        }
                    });
                } else {
                    /**当前线程为子线程**/
                    try {
                        Response response = call.execute();
                        subscriber.onNext(mRequest.getCover().just(response, type, mRequest.getSoapElement()));
                        subscriber.onCompleted();
                    } catch (Exception e) {
                        subscriber.onError(e);
                    }
                }
            }
        };
    }

    public static QBaseRxAdapterCover creat() {
        return new QBaseRxAdapterCover();
    }
}
