package com.posun.lighthttplibrary.adapterCover;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
/**获取泛型类型**/
public class Main {
	public static void getSuperClassGenricType(Class clazz)
			throws IndexOutOfBoundsException {
	    	Type[] genType = clazz.getGenericInterfaces();
	    	digui(genType[0]);
	}

	private static void digui(Type type) {
		if (Class.class.isInstance(type)) {
			System.out.println(type);
			return;
		} else {
			Type mytype = ((ParameterizedType) type).getActualTypeArguments()[0];
			digui(mytype);
		}
	}
}
