package com.posun.reflect;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by zyq on 2017/1/13.
 * 反射获得的对象包装类
 */
public class ReflexObject {
    Object object;
    Class myclass;
    protected ReflexObject(Class myclass, Class[] classes, Object[] objects){
       this.myclass=myclass;
        try {
            Constructor constructor= myclass.getDeclaredConstructor(classes);
            constructor .setAccessible(true);
            object=constructor .newInstance(objects);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /***
     *获取当前的真实对象
     */
    public Object getValue(){
        return object;
    }
    /**
     * 获取函数包装类
     * */
    public reflexMethond describe_Methond(String name,Class[] classes) throws Exception{
         Method method=myclass.getMethod(name,classes);
         return new reflexMethond(method);
    }
    public class reflexMethond{
       private Method method;
       protected reflexMethond(Method method){
           this.method=method;
       }
        /**
         * 执行你想要反射的函数
         * */
        public Object just_do(Object[] objects){
            if(object==null){
                throw new RuntimeException("no instence");
            }
            try {
              return  method.invoke(object,objects);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
