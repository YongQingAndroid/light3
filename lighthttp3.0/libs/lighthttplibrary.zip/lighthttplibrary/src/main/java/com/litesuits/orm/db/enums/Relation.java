package com.litesuits.orm.db.enums;

public enum Relation {
    ManyToMany,
    OneToMany,
    ManyToOne,
    OneToOne
}