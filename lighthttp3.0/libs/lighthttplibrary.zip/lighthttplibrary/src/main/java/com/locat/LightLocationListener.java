package com.locat;

public  interface LightLocationListener {
        void location(Gps gps);
        void locationName(String name);
        void fail(String reason);
    }