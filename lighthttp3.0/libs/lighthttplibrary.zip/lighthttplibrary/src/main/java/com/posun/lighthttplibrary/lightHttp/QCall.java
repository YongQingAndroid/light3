package com.posun.lighthttplibrary.lightHttp;

public interface QCall<T> {
        void onSuccess(T item);
        void onFaile(Exception e);
    }