package com.posun.Excutor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rx.Observable;
import rx.Subscriber;
/**
 * Created by zyq on 2016/7/5.
 * 线程池管理
 */
public class QExcuter {
    private static QExcuter self;
    private static int max_thread=3;
    private static final ExecutorService singlethreadserver= Executors.newSingleThreadExecutor();
    private static final ExecutorService threadserver= Executors.newFixedThreadPool(max_thread);
    public static QExcuter getSingleInstent(){
        if(self==null){
            self=new QExcuter();
        }
            return self;
    }
    /**
     * 单线程线程池
     * */
    public void excutesingleTreadPool(Runnable run){
        singlethreadserver.execute(run);
    }
    /**
     * 线程池中线程的最大数量
     * */
    public static void setMax_thread(int max_thread) {
        QExcuter.max_thread = max_thread;
    }
    /**
     * 执行线程操作
     * */
    public void excuteTreadPool(Runnable run){
        threadserver.execute(run);
    }
    public  ExecutorService getSingleExecutor(){
            return singlethreadserver;
    }
    public  ExecutorService getExecutor(){
        return threadserver;
    }
    /**
     * 单例Rxjava响应式函数线程池
     * */
    public  <T>Observable<T> getRxSingleExecutor(final Class<T> mclass){
        return   Observable.create(new Observable.OnSubscribe<T>() {
            @Override
            public void call(final Subscriber<? super T> subscriber) {
                        try {
                            subscriber.onNext(ObjectInstnet.getInstent(mclass));
                            subscriber.onCompleted();
                        } catch (Exception e) {
                            subscriber.onError(e);
                        }
            }
        });
    }
}
