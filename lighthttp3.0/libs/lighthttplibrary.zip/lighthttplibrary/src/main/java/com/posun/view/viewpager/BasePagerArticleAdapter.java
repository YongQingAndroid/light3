package com.posun.view.viewpager;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.List;
/**
 * viewpager视图复用
 * **/
public abstract class BasePagerArticleAdapter<T> extends PagerAdapter{
    protected ViewPager pager;
    private LayoutInflater inflater = null;
    private View mCurrentView;
    private List<SoftReference<LinearLayout>> viewList;
    public BasePagerArticleAdapter(Context context) {
        viewList = new ArrayList<SoftReference<LinearLayout>>();
        inflater = LayoutInflater.from(context);
    }
    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    @Override
    public void setPrimaryItem(ViewGroup container, int position, Object object) {
        mCurrentView = (View) object;
    }

    public View getPrimaryItem() {
        return mCurrentView;
    }

    @Override
    public Object instantiateItem(View container, int position) {
        if (pager == null) {
            pager = (ViewPager) container;
        }
        View view = null;
        if (viewList.size() > 0) {
            if (viewList.get(0) != null) {
                view = initView(viewList.get(0).get(), position);
                viewList.remove(0);
            }
        }
        view = initView(view, position);
        pager.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        LinearLayout view = (LinearLayout) object;
        container.removeView(view);
        viewList.add(new SoftReference<LinearLayout>(view));
    }

    private View initView(View view, int position) {
        T Holder;
        if(view==null){
            view=OnCrteatView(inflater);
            Holder=OnCrteatHolder(view);
            view.setTag(Holder);
        }else{
            Holder=(T)view.getTag();
        }
        RebindData(Holder,position);
        return view;
    }
    public abstract void RebindData(T holder,int posion);
    protected abstract View OnCrteatView(LayoutInflater mLayoutInflater);
    protected abstract T OnCrteatHolder(View mview);
    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == arg1;
    }
}